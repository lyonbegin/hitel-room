plugins { id("com.android.application") }
android {
    namespace = "app.hitel.samsungprobe"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.hitel.callflowlab.v7"
        minSdk = 33
        targetSdk = 33
        versionCode = 7
        versionName = "0.7.0-live-samsung-transcript"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
