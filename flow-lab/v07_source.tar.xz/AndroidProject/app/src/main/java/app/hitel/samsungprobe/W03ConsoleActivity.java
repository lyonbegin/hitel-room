package app.hitel.samsungprobe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** A single persistent HITEL cockpit. Only the carrier-owned UI is opened for
 *  operations requiring a visible Samsung accessibility tree; no default dialer replacement.
 *  A touchable accessibility overlay returns the user to this screen. */
public final class W03ConsoleActivity extends Activity {
    private static final String[] LANGS={"한국어","English","中文","日本語"};
    private static final String[] TAGS={"ko-KR","en-US","zh-CN","ja-JP"};
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<String> entries=new ArrayList<>();
    private final ArrayList<String> transcriptEntries=new ArrayList<>();
    private ArrayAdapter<String> transcriptAdapter;
    private ListView transcriptList;
    private TextView transcriptMonitor;
    private long transcriptCursor=0;
    private File transcriptReadFile;
    private long backgroundProbeBaseline=0;
    private long backgroundProbeStarted=0;
    private boolean backgroundProbeActive=false;
    private boolean followTranscripts=true;
    private SpeechRecognizer recognizer;
    private boolean isListening=false, recordStarted=false, scanRunning=false,sendWaiting=false, sentAttempted=false;
    private boolean editingText=false, followLogs=true, sttSucceeded=false, testOpen=false;
    private String lastSttError="", lastSttResult="", attemptedMode="", lastSendResult="", deviceCallState="";
    private String lastRemoteShown="", lastLocalShown="";
    private int completedSteps=0, lastCount=0;
    private long cursor=0;
    private EditText phone, message;
    private TextView callState, textCallState, remoteSubtitle, sentSubtitle, status, logHeader, flowStatus;
    private Button callButton, textCallButton, sttButton, oemButton, smsButton, voiceButton, endButton, autoScroll;
    private Spinner language;
    private ListView logList;
    private ArrayAdapter<String> logAdapter;
    private final Runnable poll=new Runnable(){
        @Override public void run(){
            if(isFinishing())return;
            refreshState();refreshTranscripts();refreshLogs();
            ui.postDelayed(this,500);
        }
    };
    private int dp(float a){return (int)(getResources().getDisplayMetrics().density*a+0.5f);}
    private TextView label(String t,int size,boolean bold){
        TextView v=new TextView(this);v.setText(t);v.setTextColor(0xff111111);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        if(bold)v.setTypeface(null,1);
        v.setPadding(dp(3),dp(4),dp(3),dp(4));return v;
    }
    private Button btn(String t,Runnable job){
        Button b=new Button(this);b.setAllCaps(false);b.setTextSize(TypedValue.COMPLEX_UNIT_SP,12);
        b.setText(t);b.setOnClickListener(v->job.run());return b;
    }
    private void toast(String v){Toast.makeText(this,v,Toast.LENGTH_LONG).show();}
    private void log(String type,String msg){LabStore.log(type,msg);}
    private void status(String message){status.setText(message);}
    private LinearLayout container(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private void line(LinearLayout parent,String title){
        TextView t=label(title,15,true);t.setBackgroundColor(0xfff1f1f1);
        t.setPadding(dp(9),dp(9),dp(9),dp(9));parent.addView(t,new LinearLayout.LayoutParams(-1,-2));
    }
    private void addButtonRow(LinearLayout parent,Button... buttons){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        for(Button b:buttons)row.addView(b,new LinearLayout.LayoutParams(0,dp(54),1));
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);ScenarioCatalog.load(this);FlowCatalog.load(this);LabStore.init(this);
        LinearLayout screen=container();screen.setBackgroundColor(Color.WHITE);
        screen.setPadding(dp(10),dp(8),dp(10),dp(8));
        screen.addView(label("W03  |  전화 중 음성 입력 · 실시간 조작",19,true));
        flowStatus=label("이 화면을 보면서 통화를 진행합니다.",12,false);screen.addView(flowStatus);
        ScrollView sc=new ScrollView(this);LinearLayout content=container();
        sc.addView(content);screen.addView(sc,new LinearLayout.LayoutParams(-1,0,7));
        line(content,"① 통화 연결");
        phone=new EditText(this);phone.setSingleLine(true);phone.setTextSize(16);
        phone.setHint("시험 상대방 전화번호 (미입력 시 이미 연결된 통화 사용)");
        phone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);content.addView(phone);
        callState=label("통화 상태 확인 중",13,false);content.addView(callState);
        callButton=btn("전화 걸기",this::placeCall);
        Button connected=btn("연결 상태 확인",this::refreshState);
        addButtonRow(content,callButton,connected);
        content.addView(label("전화 앱 화면이 나타나면 화면 위의 'HITEL로 돌아오기'를 누르십시오. 통화는 계속됩니다.",12,false));

        line(content,"② 삼성 문자통화 준비");
        textCallState=label("삼성 문자통화: 실제 화면 관측 전",13,false);content.addView(textCallState);
        textCallButton=btn("문자통화 화면 실행·확인",this::prepareTextCall);
        Button returnCall=btn("삼성 전화 화면 잠깐 보기",this::openCallUi);
        addButtonRow(content,textCallButton,returnCall);
        content.addView(label("삼성 전화 화면이 보일 때만 문자통화 버튼 조작이 가능합니다. 숨겨진 전화 화면의 내용을 무조건 읽을 수 있는 것은 아닙니다.",11,false));

        line(content,"③ 삼성 문자통화 전체 자막 · 실시간 중계");
        transcriptMonitor=label("삼성 원본 자막 이벤트 대기. 백그라운드 수집 가능 여부는 실제 이벤트로 확인합니다.",12,true);
        content.addView(transcriptMonitor);
        Button probe=btn("삼성 화면을 숨긴 채 새 자막 수집 시험 (15초)",this::startBackgroundProbe);
        content.addView(probe,new LinearLayout.LayoutParams(-1,dp(48)));
        content.addView(label("상대방 원문·번역문·내 메시지·정정 이력을 한 줄도 자르지 않고 기록합니다. 삼성에서 실제로 발생한 새 이벤트만 추가합니다.",11,false));
        transcriptList=new ListView(this);transcriptList.setDividerHeight(1);
        transcriptAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,transcriptEntries){
            @Override public View getView(int position,View old,android.view.ViewGroup parent){
                TextView v=old instanceof TextView?(TextView)old:new TextView(W03ConsoleActivity.this);
                v.setText(transcriptEntries.get(position));v.setTextColor(0xff222222);
                v.setTextSize(14);v.setSingleLine(false);v.setMaxLines(Integer.MAX_VALUE);
                v.setPadding(dp(8),dp(8),dp(8),dp(8));
                v.setBackgroundColor(position%2==0?0xfff7f7f7:Color.WHITE);return v;
            }
        };
        transcriptList.setAdapter(transcriptAdapter);
        transcriptList.setOnTouchListener((v,event)->{
            if(event.getAction()==android.view.MotionEvent.ACTION_DOWN)followTranscripts=false;
            return false;
        });
        content.addView(transcriptList,new LinearLayout.LayoutParams(-1,dp(270)));
        Button bottom=btn("자막 최신으로 이동 · 자동 스크롤 재개",()->{
            followTranscripts=true;
            if(!transcriptEntries.isEmpty())transcriptList.setSelection(transcriptEntries.size()-1);
        });
        content.addView(bottom,new LinearLayout.LayoutParams(-1,dp(44)));
        remoteSubtitle=label("상대방 마지막 자막: 대기 중",13,true);content.addView(remoteSubtitle);
        sentSubtitle=label("내 마지막 메시지: 대기 중",12,false);content.addView(sentSubtitle);

        line(content,"④ 내 목소리 → 인식 문장");
        language=new Spinner(this);language.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,LANGS));
        content.addView(language);
        sttButton=btn("🎙 여기서 바로 말하기 (STT)",this::startSpeech);
        Button stop=btn("음성 인식 중지",this::stopSpeech);
        addButtonRow(content,sttButton,stop);
        message=new EditText(this);message.setMinLines(3);message.setTextSize(17);
        message.setGravity(Gravity.TOP);message.setHint("음성 인식 결과가 여기 표시됩니다. 직접 수정·입력하실 수도 있습니다.");
        message.setSingleLine(false);content.addView(message,new LinearLayout.LayoutParams(-1,dp(92)));
        content.addView(label("이 문장은 사용자께서 전송 방식을 누르기 전까지 상대방에게 보내지지 않습니다.",11,false));

        line(content,"⑤ 전송 방식 선택 (사용자가 직접 누릅니다)");
        oemButton=btn("삼성 문자통화 TTS 보내기",()->confirmSend("oem_tts"));
        smsButton=btn("SMS 문자 작성",()->confirmSend("sms"));
        voiceButton=btn("일반 음성으로 전환",()->confirmSend("voice"));
        content.addView(oemButton,new LinearLayout.LayoutParams(-1,dp(52)));
        addButtonRow(content,smsButton,voiceButton);
        status=label("단계별 실제 결과를 여기에 표시합니다.",13,false);
        status.setBackgroundColor(0xffeeeeee);content.addView(status);

        line(content,"⑥ 실제 상대방 확인 · 결과 저장");
        Button heard=btn("상대방이 TTS 들음",()->peerCheck(true));
        Button notHeard=btn("상대방이 못 들음",()->peerCheck(false));
        addButtonRow(content,heard,notHeard);
        endButton=btn("W03 종료 · 결과 ZIP 저장",this::endSession);
        content.addView(endButton,new LinearLayout.LayoutParams(-1,dp(52)));

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        logHeader=label("전체 실행 로그 · 0줄",13,true);
        head.addView(logHeader,new LinearLayout.LayoutParams(0,dp(40),1));
        autoScroll=btn("자동 스크롤 ON",()->{followLogs=!followLogs;autoScroll.setText(followLogs?"자동 스크롤 ON":"자동 스크롤 OFF");});
        head.addView(autoScroll,new LinearLayout.LayoutParams(dp(139),dp(40)));
        screen.addView(head);
        logList=new ListView(this);logList.setDividerHeight(1);
        logAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,entries){
            @Override public View getView(int position,View old,android.view.ViewGroup parent){
                TextView text=old instanceof TextView?(TextView)old:new TextView(W03ConsoleActivity.this);
                text.setText(entries.get(position));text.setTextSize(11);text.setTextColor(0xff1f1f1f);
                text.setPadding(dp(5),dp(4),dp(5),dp(4));text.setSingleLine(false);
                text.setMaxLines(Integer.MAX_VALUE);text.setBackgroundColor(position%2==0?0xfff6f6f6:Color.WHITE);return text;
            }
        };
        logList.setAdapter(logAdapter);
        logList.setOnTouchListener((v,event)->{if(event.getAction()==android.view.MotionEvent.ACTION_DOWN){followLogs=false;autoScroll.setText("자동 스크롤 OFF");}return false;});
        screen.addView(logList,new LinearLayout.LayoutParams(-1,0,3));
        setContentView(screen);
        if(!LabStore.running()){
            try{LabStore.begin(this,"flow","W03");recordStarted=true;log("W03_UI_BEGIN","W03 전면 조작 UI 시작. 전화 앱을 기본앱으로 교체하지 않음");}
            catch(Throwable e){status("시험 기록 시작 불가: "+e);}
        }else{recordStarted="W03".equals(LabStore.currentScenario());if(!recordStarted)status("다른 시험 실행 중: "+LabStore.currentScenario());}
        CallAccessibilityService.setConsoleRequested(true);
        ui.post(poll);
    }
    private void step(int index,String action,String verdict,String reason){
        if(!recordStarted)return;
        LabStore.saveFlowStep(index,6,action,action,verdict,reason);
        completedSteps=Math.max(completedSteps,index+1);
    }
    private boolean has(String permission){return checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;}
    private void placeCall(){
        String number=phone.getText().toString().trim();
        if(number.isEmpty()){toast("시험 전화번호를 입력하시거나 이미 연결된 통화를 사용해 주십시오.");return;}
        if(!number.matches("[+0-9#*() -]{2,25}")){toast("전화번호 형식을 확인해 주십시오.");return;}
        if(!has(Manifest.permission.CALL_PHONE)){requestPermissions(new String[]{Manifest.permission.CALL_PHONE},601);return;}
        new AlertDialog.Builder(this).setTitle("시험 상대방에게 실제 전화 발신")
            .setMessage(number+"\n\n발신하면 삼성 전화 화면이 잠시 전면에 표시될 수 있습니다. 화면 위의 'HITEL로 돌아오기'로 이 조작 화면을 다시 여실 수 있습니다.")
            .setNegativeButton("취소",null).setPositiveButton("전화 연결",(d,w)->{
                try{
                    step(0,"일반전화 발신 요청","UNVERIFIED","사용자가 발신을 직접 승인함; 수신자가 응답했는지는 별도 검증");
                    log("USER_CALL_REQUEST","사용자가 전화 발신을 승인함. number=***"+(number.length()>3?number.substring(number.length()-3):""));
                    startActivity(new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+number.replaceAll("[() -]",""))));
                }catch(Throwable ex){status("발신 화면 실행 실패: "+ex);log("CALL_START_ERROR",ex.toString());}
            }).show();
    }
    private void refreshState(){
        if(!recordStarted)return;
        try{
            if(!has(Manifest.permission.READ_PHONE_STATE)){
                callState.setText("통화 상태 권한이 없습니다. 최초 1회 요청해야 합니다.");
                return;
            }
            TelephonyManager tel=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
            int state=tel.getCallState();
            String newState=state==TelephonyManager.CALL_STATE_OFFHOOK?"통화 중/발신 중(OS OFFHOOK)":
                state==TelephonyManager.CALL_STATE_RINGING?"전화 수신 중":state==TelephonyManager.CALL_STATE_IDLE?"전화 연결 없음":"상태 알 수 없음";
            if(!newState.equals(deviceCallState)){log("W03_PHONE_STATE",newState);deviceCallState=newState;}
            callState.setText("전화 상태: "+newState+" · 실제 상대방 응답 여부는 별도 확인");
        }catch(Throwable e){callState.setText("전화 상태 조회 오류: "+e);}
        CallAccessibilityService access=CallAccessibilityService.instance;
        if(access!=null){
            CallAccessibilityService.Snapshot s=access.snapshot();
            String latest=s.lastRemote;
            if(!latest.equals(lastRemoteShown)){
                lastRemoteShown=latest;
                if(!latest.isEmpty()){
                    remoteSubtitle.setText("상대방 (관측된 자막):\n"+latest);
                    log("W03_UI_REMOTE","관측된 삼성 문자통화 자막이 전면 화면에 표시됨. package="+s.foregroundPackage);
                }
            }
            if(!s.lastLocal.equals(lastLocalShown)){
                lastLocalShown=s.lastLocal;
                sentSubtitle.setText("삼성에서 관측된 내 메시지: "+(lastLocalShown.isEmpty()?"없음":lastLocalShown));
            }
            String support=s.textCall?"삼성 문자 입력 노드 관측됨(숨긴 화면 접근은 미보장)":"입력 노드 아직 확인 안 됨";
            textCallState.setText("삼성 문자통화: "+support+" · 접근성 창: "+(s.foregroundPackage.isEmpty()?"미확인":s.foregroundPackage));
            updateTranscriptHealth(s);
        }else{textCallState.setText("접근성 연결 필요 — 아래 삼성 화면 자동 조작 불가");}
        flowStatus.setText("HITEL 전면 조작 중 · "+(sendWaiting?"삼성 전송 요청 진행":"입력/전송 대기")+" · 전체 로그 "+entries.size()+"줄");
        oemButton.setEnabled(!sendWaiting&&recordStarted);
        sttButton.setEnabled(!isListening&&recordStarted);
    }
    private void openCallUi(){
        if(!recordStarted)return;
        try{TelecomManager t=(TelecomManager)getSystemService(TELECOM_SERVICE);
            log("W03_OPEN_OEM_UI","TelecomManager.showInCallScreen(false); 전화 앱 화면 일시 노출. 반드시 사용자 반환 버튼 제공");
            t.showInCallScreen(false);
        }catch(Throwable e){log("W03_OEM_UI_ERROR",e.toString());status("삼성 전화 화면 호출 실패: "+e);}
    }
    private void prepareTextCall(){
        if(!recordStarted)return;
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null){toast("설정에서 'HITEL 통화 실시간 조작' 접근성을 활성화해 주십시오.");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));return;}
        if(scanRunning)return;scanRunning=true;
        status("삼성 전화 화면을 열어 문자통화 버튼을 찾습니다. 전화 화면 위의 HITEL 복귀 버튼을 사용해 주십시오.");
        step(1,"삼성 문자통화 준비","UNVERIFIED","실제 삼성 화면 노드 탐색 대기");
        openCallUi();
        io.execute(()->{
            try{Thread.sleep(1250);a.scanBlocking("w03_textcall_start");
                boolean already=a.isTextCallVisible();
                boolean clicked=already||a.enterTextCall();
                log("W03_TEXT_CALL_ACTION","alreadyVisible="+already+" enterClick="+clicked+" (클릭 성공=문자통화 활성화가 아님)");
                Thread.sleep(1500);a.scanBlocking("w03_textcall_verify");
                boolean visible=a.isTextCallVisible();
                step(1,"삼성 문자통화 진입",visible?"PASS":"UNVERIFIED",visible?"실제 삼성 문자 입력 노드 관측":"삼성 문자 입력창 미노출. 원본 화면에서 수동 진입 후 다시 확인");
                ui.post(()->status(visible?"삼성 문자통화 입력창 확인됐습니다. HITEL 복귀 버튼으로 돌아오십시오.":"문자통화 자동 진입 미확인. 삼성 화면에서 문자통화를 켜신 뒤 HITEL로 돌아오십시오."));
            }catch(Throwable e){log("W03_TEXT_CALL_EXCEPTION",e.toString());ui.post(()->status("문자통화 탐색 오류: "+e));}
            finally{scanRunning=false;}
        });
    }
    private void startSpeech(){
        if(!recordStarted)return;
        if(isListening)return;
        if(!has(Manifest.permission.RECORD_AUDIO)){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},602);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){
            status("이 기기에 STT 음성인식 서비스가 없습니다. 문장을 직접 입력하실 수 있습니다.");
            log("W03_STT_UNSUPPORTED","SpeechRecognizer unavailable; manual typing supported");return;
        }
        stopSpeech();
        String lang=TAGS[language.getSelectedItemPosition()];sttSucceeded=false;lastSttResult="";lastSttError="";
        try{
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle params){status("마이크 활성 · 지금 말씀하십시오.");log("W03_STT_READY","language="+lang);}
                @Override public void onBeginningOfSpeech(){status("발화 인식 중");}
                @Override public void onEndOfSpeech(){status("음성 분석 중");}
                @Override public void onRmsChanged(float rms){}
                @Override public void onBufferReceived(byte[] b){}
                @Override public void onPartialResults(Bundle result){
                    ArrayList<String> values=result.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(values!=null&&!values.isEmpty())status("듣는 중: "+values.get(0));
                }
                @Override public void onResults(Bundle result){
                    ArrayList<String> values=result.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    isListening=false;
                    if(values!=null&&!values.isEmpty()&&!values.get(0).isBlank()){
                        lastSttResult=values.get(0);message.setText(lastSttResult);sttSucceeded=true;
                        step(3,"내 음성 인식", "UNVERIFIED","STT 텍스트 확보; 실제 발화 정확도는 사용자 확인 필요");
                        log("W03_STT_RESULT",lastSttResult);
                        status("인식 완료. 아래 문장을 수정한 다음 전송 버튼을 선택하십시오.");
                    }else{lastSttError="EMPTY_RESULT";status("인식된 문장이 없습니다. 재시도 또는 직접 입력하십시오.");}
                    destroyRecognizer();
                }
                @Override public void onError(int code){isListening=false;lastSttError="ERROR_"+code;
                    log("W03_STT_ERROR","errorCode="+code+" (7=NO_MATCH; 권한·마이크 독점 확정 아님)");
                    status("STT 인식 실패 코드 "+code+". 다시 말하거나 아래에 직접 입력하십시오.");destroyRecognizer();}
                @Override public void onEvent(int type,Bundle data){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,lang);i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
            recognizer.startListening(i);isListening=true;
            step(2,"HITEL 전면 마이크 입력","UNVERIFIED","SpeechRecognizer.startListening 호출; 실제 인식 결과 대기");
            log("W03_STT_START","HITEL native foreground; lang="+lang);
        }catch(Throwable e){isListening=false;lastSttError=e.toString();destroyRecognizer();status("인식 시작 오류: "+e);log("W03_STT_START_FAIL",e.toString());}
    }
    private void stopSpeech(){
        if(recognizer!=null&&isListening){try{recognizer.stopListening();status("음성 인식을 종료하고 결과를 확인합니다.");}catch(Throwable e){log("W03_STT_STOP_ERROR",e.toString());}}
    }
    private void destroyRecognizer(){
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Throwable ignored){}recognizer=null;}
    }
    private void confirmSend(String mode){
        if(!recordStarted)return;
        String value=message.getText().toString().trim();
        if(value.isEmpty()&&!"voice".equals(mode)){toast("보낼 문장을 먼저 말하거나 입력해 주십시오.");return;}
        if(sendWaiting){toast("이전 전송 동작이 완료될 때까지 기다려 주십시오.");return;}
        if("oem_tts".equals(mode))new AlertDialog.Builder(this)
           .setTitle("실제 삼성 TTS 전송 시험")
           .setMessage("전송할 문장:\n"+value+"\n\n삼성 문자통화 화면을 잠시 열어 실제 입력창과 전송 버튼을 조작합니다. 원본 전화 화면이 보이는 동안 'HITEL로 돌아오기' 버튼이 표시됩니다. 상대방에게 실제 합성음이 들렸는지는 별도로 확인합니다.")
           .setNegativeButton("취소",null).setPositiveButton("TTS 전송 시도",(d,w)->sendOem(value)).show();
        else if("sms".equals(mode))new AlertDialog.Builder(this).setTitle("SMS로 작성")
           .setMessage("전화 회선으로 합성음이 나가는 것이 아니라 별도 문자 앱에 입력합니다. SMS를 실제로 보내는 동작은 사용자가 직접 합니다.")
           .setNegativeButton("취소",null).setPositiveButton("문자 작성 열기",(d,w)->openSms(value)).show();
        else new AlertDialog.Builder(this).setTitle("일반 음성통화로 변경")
           .setMessage("직접 목소리로 말하기 위해 삼성 문자통화에서 일반 통화로 전환합니다. 인식된 텍스트/녹음 음성을 회선에 주입하는 기능이 아닙니다.")
           .setNegativeButton("취소",null).setPositiveButton("삼성 음성통화 전환",(d,w)->switchToVoice()).show();
    }
    private void sendOem(String text){
        attemptedMode="oem_tts";sentAttempted=false;sendWaiting=true;lastSendResult="";
        String src=sttSucceeded?(text.equals(lastSttResult)?"STT":"STT_EDITED"):"MANUAL";
        LabStore.saveVoiceDecision(text,"oem_tts",src,TAGS[language.getSelectedItemPosition()],lastSttError);
        log("W03_USER_SEND_OEM","명시적 사용자 승인; 삼성 Text Call 입력창으로 TTS 전송 시도");
        status("삼성 화면을 잠시 호출해 원본 입력창/전송 버튼을 탐색 중입니다.");
        if(!testOpen){LabStore.startTest("T07");testOpen=true;}
        step(4,"삼성 TTS 전송 선택","UNVERIFIED","실제 삼성 전송 버튼 동작 확인 대기");
        openCallUi();
        io.execute(()->{
            boolean clicked=false,visible=false;
            CallAccessibilityService a=CallAccessibilityService.instance;
            try{
                Thread.sleep(1250);
                if(a!=null){a.scanBlocking("w03_before_oem_send");visible=a.isTextCallVisible();
                    if(!visible){a.enterTextCall();Thread.sleep(1000);}
                    a.scanBlocking("w03_pre_send");visible=a.isTextCallVisible();
                    if(visible){clicked=a.putAndSend(text);a.scanBlocking("w03_after_oem_send");}
                    else log("W03_SEND_NO_OEM_NODE","Samsung 문자 입력창 접근성 노드 없음; 임의 좌표로 전송하지 않음");
                }else log("W03_SEND_NO_ACCESSIBILITY","접근성 서비스 비활성화");
            }catch(Throwable e){log("W03_SEND_EXCEPTION",e.toString());}
            final boolean ok=clicked,seen=visible;
            ui.post(()->{
                sendWaiting=false;sentAttempted=ok;
                lastSendResult=ok?"삼성 전송 버튼 클릭 확인. 상대방 TTS 수신은 아직 미확인":
                    "삼성 Text Call 입력창/전송 버튼 조작 실패. 실제 상대방 송출 미확인";
                step(4,"삼성 문자통화 TTS 전달", "UNVERIFIED",lastSendResult);
                status(lastSendResult+"\nHITEL 복귀 버튼으로 돌아와 상대방 청취 여부를 확인해 주십시오.");
                log("W03_OEM_SEND_RESULT","visibleNode="+seen+" clicked="+ok+"; peerAudioNotProven=true");
            });
        });
    }
    private void openSms(String text){
        attemptedMode="sms";LabStore.saveVoiceDecision(text,"sms",sttSucceeded?"STT_EDITED_OR_ORIGINAL":"MANUAL",TAGS[language.getSelectedItemPosition()],lastSttError);
        step(4,"SMS 별도 작성","UNVERIFIED","문자 작성 앱으로 전달; 문자 실제 송신은 사용자 확인 필요");
        try{Intent sms=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"));sms.putExtra("sms_body",text);startActivity(sms);
            log("W03_SMS_COMPOSER","문자 입력창 열기, 실제 발송은 직접 확인");}
        catch(Throwable e){status("SMS 작성 앱 열기 실패: "+e);log("W03_SMS_FAIL",e.toString());}
    }
    private void switchToVoice(){
        attemptedMode="voice";
        step(4,"일반 음성통화 직접 발화","UNVERIFIED","사용자가 직접 음성 모드 전환을 선택함");
        status("삼성 전화 화면을 열어 일반 음성 전환을 시도합니다. 실제 전환 성공 여부를 확인해 주십시오.");
        openCallUi();
        io.execute(()->{
            try{Thread.sleep(1150);
                CallAccessibilityService a=CallAccessibilityService.instance;
                boolean clicked=a!=null&&a.switchToVoiceCall();
                log("W03_VOICE_SWITCH","삼성 일반 음성 전환 버튼 clicked="+clicked);
                ui.post(()->status(clicked?"일반 음성통화 전환 버튼 조작. 실제 모드 전환 확인 필요.":"삼성 일반 음성 전환 버튼을 찾지 못했습니다. 원본 화면에서 직접 전환해 주십시오."));
            }catch(Throwable e){log("W03_VOICE_SWITCH_ERROR",e.toString());}
        });
    }
    private void peerCheck(boolean heard){
        if(!recordStarted)return;
        if(!"oem_tts".equals(attemptedMode)){
            toast("먼저 삼성 TTS 전송을 선택해 주십시오. SMS/일반 음성에는 TTS 청취 판정을 적용하지 않습니다.");return;
        }
        new AlertDialog.Builder(this).setTitle("상대방 직접 확인")
            .setMessage("실제 통화 상대방께서 삼성 합성음을 "+(heard?"들으셨다고":"듣지 못하셨다고")+" 확인하신 결과입니까?\n\n자동 판정이 아닌 사용자 확인으로 별도 기록됩니다.")
            .setNegativeButton("취소",null).setPositiveButton("확인 결과 저장",(d,w)->{
                String s=heard?"PASS":"FAIL";
                if(testOpen){
                    LabStore.markManual(s,heard?"상대방이 TTS 들음 (사용자 보고)":"상대방 TTS 미수신 (사용자 보고)");
                    try{JSONObject evidence=new JSONObject().put("sendClickObserved",sentAttempted).put("userReportedPeerHeard",heard)
                        .put("observedDelivery",false).put("source","MANUAL_PEER_CONFIRM");
                        LabStore.finishTest(this,s,heard?"사용자 보고: 상대방 삼성 합성음 청취":"사용자 보고: 상대방 합성음 미수신",evidence);
                    }catch(Throwable e){log("W03_TEST_FINALIZE_ERROR",e.toString());}
                    testOpen=false;
                }
                step(5,"상대방 청취 확인",s,"사용자 직접 확인 결과. 객관적 상대방 녹음 증거와는 구분");
                status("상대방 확인 기록: "+(heard?"청취 성공":"미수신")+" (사용자 보고). 종료·ZIP 저장을 누르십시오.");
            }).show();
    }
    private void endSession(){
        if(!recordStarted){finish();return;}
        new AlertDialog.Builder(this).setTitle("W03 테스트 종료·저장")
          .setMessage("통화 자체를 종료하지 않고 이번 진단 기록만 ZIP으로 저장합니다. 화면에 보이지 않는 원본 로그도 모두 포함합니다.")
          .setNegativeButton("취소",null).setPositiveButton("ZIP 저장",(d,w)->{
            if(testOpen){
                try{JSONObject proof=new JSONObject().put("sendClickObserved",sentAttempted).put("manualConfirmation",false);
                    LabStore.finishTest(this,"UNVERIFIED","사용자 상대방 청취 확인 없이 종료됨. 전송버튼 동작만으로 성공 처리하지 않음",proof);
                }catch(Throwable e){log("W03_TEST_END_ERROR",e.toString());}testOpen=false;
            }
            LabStore.finishRun(this,"W03 전면 조작 종료. 단계별 결과와 전체 로그 저장");
            recordStarted=false;CallAccessibilityService.setConsoleRequested(false);
            status("저장됨: "+LabStore.lastExport());
            toast("Download 파일: "+LabStore.lastExport());
          }).show();
    }
    private void updateTranscriptHealth(CallAccessibilityService.Snapshot snapshot){
        long now=System.currentTimeMillis();
        boolean samsungFront=snapshot.foregroundPackage.startsWith("com.samsung.");
        long age=snapshot.lastSamsungTranscriptAt==0?-1:now-snapshot.lastSamsungTranscriptAt;
        String state;
        if(age>=0&&age<3500)state="실시간 관측 (마지막 자막 "+(age/1000)+"초 전)";
        else if(age>=0)state="마지막 자막 "+(age/1000)+"초 전 · 새 이벤트 수신 대기";
        else state="자막 이벤트 미관측";
        if(!samsungFront&&snapshot.lastSamsungEventAt>0){
            long evAge=now-snapshot.lastSamsungEventAt;
            state+="\n삼성은 현재 백그라운드 · 마지막 OEM 접근성 이벤트 "+(evAge/1000)+"초 전";
        }
        if(!samsungFront&&(snapshot.lastBackgroundTranscriptAt==0||now-snapshot.lastBackgroundTranscriptAt>3500)){
            state+="\n주의: 백그라운드 신규 자막은 OS/OEM이 이벤트를 제공해야 수집됩니다. 자동 수집 보장 불가";
        }
        state+="\n확보된 원문/송신/번역 기록 "+transcriptEntries.size()+"건";
        transcriptMonitor.setText(state);
        if(backgroundProbeActive){
            if(snapshot.lastBackgroundTranscriptAt>backgroundProbeStarted &&
               snapshot.backgroundMessageCount>backgroundProbeBaseline &&
               snapshot.lastMessageSource.startsWith("event:")){
                backgroundProbeActive=false;
                LabStore.saveBackgroundProbe("PASS",backgroundProbeBaseline,snapshot.backgroundMessageCount,
                    "삼성 비전면 상태에서 실제 접근성 이벤트 출처의 자막 수집, source="+snapshot.lastMessageSource);
                log("W03_BACKGROUND_PROBE_PASS","실제 신규 자막이 삼성 비전면 상태에서 수집됨");
                status("백그라운드 신규 자막 수집 확인. 대화 목록에서 실제 문장을 확인하십시오.");
            }else if(now-backgroundProbeStarted>15000){
                backgroundProbeActive=false;
                LabStore.saveBackgroundProbe("UNVERIFIED",backgroundProbeBaseline,snapshot.backgroundMessageCount,
                    "15초 내 삼성 비전면 신규 자막 이벤트 입증 실패. 실제 발화 여부 및 OEM 이벤트 제공 여부는 별도 확인");
                log("W03_BACKGROUND_PROBE_UNVERIFIED","15초 동안 새 Samsung 자막 이벤트 관측 안 됨. 임의 성공 처리 안 함");
                status("백그라운드 수집 확인 안 됨. 삼성 앱이 숨겨진 상태에서 접근성 이벤트를 제공하지 않았을 수 있습니다.");
            }
        }
    }
    private void startBackgroundProbe(){
        if(!recordStarted)return;
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null){status("접근성 서비스를 먼저 활성화해 주십시오.");return;}
        CallAccessibilityService.Snapshot snap=a.snapshot();
        backgroundProbeBaseline=snap.backgroundMessageCount;
        backgroundProbeStarted=System.currentTimeMillis();backgroundProbeActive=true;
        log("W03_BACKGROUND_PROBE_BEGIN","사용자 요청: HITEL 화면 전면 유지, 상대방이 새 문장을 발화한 뒤 실제 삼성 이벤트 수집 시험");
        status("지금 우리 앱을 계속 보시면서 상대방께 새로운 문장 두 개를 말씀해 달라고 요청하십시오. 15초 동안 실제 이벤트를 검사합니다.");
    }
    /** Reads the entire running transcript JSONL incrementally, without truncating or inventing missing events. */
    private void refreshTranscripts(){
        File f=LabStore.transcriptsFile(this);
        if(f==null)return;
        if(transcriptReadFile==null||!transcriptReadFile.equals(f)){
            transcriptReadFile=f;transcriptCursor=0;transcriptEntries.clear();
            transcriptAdapter.notifyDataSetChanged();
        }
        if(!f.exists())return;
        if(f.length()<transcriptCursor){transcriptCursor=0;transcriptEntries.clear();transcriptAdapter.notifyDataSetChanged();}
        int appended=0;
        try(RandomAccessFile reader=new RandomAccessFile(f,"r")){
            reader.seek(transcriptCursor);String encoded;
            while((encoded=reader.readLine())!=null){
                transcriptCursor=reader.getFilePointer();
                String line=new String(encoded.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
                if(line.isBlank())continue;
                try{
                    JSONObject item=new JSONObject(line);
                    String id=item.optString("viewId","");
                    String who=id.contains("remote_message_translated")?"상대방 · 번역":
                               id.contains("local_message_translated")?"내 발신 · 번역":
                               "remote".equals(item.optString("direction"))?"상대방": "내 발신";
                    long ms=item.optLong("timestampMs",0L);
                    String at=ms>0?new java.text.SimpleDateFormat("HH:mm:ss.SSS",Locale.KOREA).format(new java.util.Date(ms)):"시간 미확인";
                    String changed="UPDATED".equals(item.optString("update"))?" · 정정":"";
                    String bg=item.optBoolean("background")?" · 백그라운드 이벤트":"";
                    transcriptEntries.add(at+"  "+who+changed+bg+"\n"+item.optString("text")+"\n["+item.optString("source","actual_accessibility_node")+"]");
                    appended++;
                }catch(Exception e){log("W03_TRANSCRIPT_DECODE_ERROR",e.toString());}
            }
        }catch(Exception e){log("W03_TRANSCRIPT_READ_ERROR",e.toString());}
        if(appended>0){transcriptAdapter.notifyDataSetChanged();
            if(followTranscripts)transcriptList.setSelection(transcriptEntries.size()-1);
        }
    }
    private void refreshLogs(){
        File f=LabStore.logFile(this);if(f.length()<cursor){cursor=0;entries.clear();logAdapter.notifyDataSetChanged();}
        int added=0;
        try(RandomAccessFile r=new RandomAccessFile(f,"r")){
            r.seek(cursor);String line;
            while((line=r.readLine())!=null){cursor=r.getFilePointer();String raw=new String(line.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
                if(raw.isBlank())continue;
                try{JSONObject j=new JSONObject(raw);entries.add("["+j.optString("time")+"] "+j.optString("type")+": "+j.optString("message"));}
                catch(Exception ex){entries.add(raw);}
                added++;
            }
        }catch(Throwable e){/* retry next poll; original file is untouched */}
        if(added>0){logAdapter.notifyDataSetChanged();logHeader.setText("전체 실행 로그 · "+entries.size()+"줄");
            if(followLogs)logList.setSelection(logAdapter.getCount()-1);}
    }
    @Override public void onRequestPermissionsResult(int req,String[] perm,int[] result){
        super.onRequestPermissionsResult(req,perm,result);
        if(result.length>0&&result[0]==PackageManager.PERMISSION_GRANTED){
            if(req==601)placeCall();else if(req==602)startSpeech();else if(req==603)refreshState();
        }else{toast("필요한 권한이 허용되지 않았습니다. 가능한 기능만 사용하실 수 있습니다.");}
    }
    @Override protected void onResume(){super.onResume();
        if(!has(Manifest.permission.READ_PHONE_STATE)){
            ui.postDelayed(()->{if(!isFinishing()&&!has(Manifest.permission.READ_PHONE_STATE))
                 requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},603);},400);
        }
    }
    @Override protected void onDestroy(){
        ui.removeCallbacks(poll);destroyRecognizer();io.shutdown();
        if(isFinishing()&&recordStarted)log("W03_UI_EXIT","화면만 닫힘. 이전에 저장한 자료 보존. 통화 강제 종료하지 않음");
        super.onDestroy();
    }
}
