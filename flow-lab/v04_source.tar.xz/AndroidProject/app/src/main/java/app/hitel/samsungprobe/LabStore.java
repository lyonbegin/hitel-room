package app.hitel.samsungprobe;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Every diagnostic line is appended to disk; the UI and exports have no tail-only cap. */
public final class LabStore {
    private static final String TAG="CallScenarioLab";
    private static File root, allLog, runDir, testDir;
    private static String runId="",scenarioId="",testId="",testNote="",runMode="";
    private static long runStarted, testStarted;
    private static int screenCounter;
    private static final Map<String,JSONObject> outcomes=new LinkedHashMap<>();
    private static String manualStatus="", manualNote="";
    private static String lastExport="";
    private LabStore(){}
    public static synchronized void init(Context context) {
        if(root!=null)return;
        root=new File(context.getFilesDir(),"HITEL_Call_Scenario_Lab");
        root.mkdirs();
        allLog=new File(root,"all_events.jsonl");
        try{if(!allLog.exists())allLog.createNewFile();}catch(Exception ignored){}
    }
    public static synchronized File logFile(Context c){init(c);return allLog;}
    public static synchronized boolean running(){return runDir!=null;}
    public static synchronized String currentTest(){return testId;}
    public static synchronized String currentScenario(){return scenarioId;}
    public static synchronized String currentRunId(){return runId;}
    public static synchronized String lastExport(){return lastExport;}
    private static String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date());}
    public static synchronized void begin(Context c,String mode,String selection) {
        init(c);
        if(runDir!=null)throw new IllegalStateException("테스트 실행 중");
        runId=stamp();scenarioId=selection;runMode=mode;
        testId="";runStarted=System.currentTimeMillis();screenCounter=0;outcomes.clear();
        runDir=new File(root,"runs/"+runId+"_"+selection);runDir.mkdirs();
        try{
            JSONObject data=new JSONObject();data.put("mode",mode).put("selection",selection).put("timestamp",runStarted);
            data.put("source",FlowCatalog.version()).put("device",Build.MANUFACTURER+" "+Build.MODEL).put("api",Build.VERSION.SDK_INT);
            FlowCatalog.Plan p=FlowCatalog.find(selection);
            if(p!=null)write(new File(runDir,"flow.json"),p.json().toString(2));
            write(new File(runDir,"run.json"),data.toString(2));
        }catch(Exception ignored){}
        log("RUN_START","실행: "+mode+" / "+selection+" | 갤럭시 기본 전화 앱을 변경하지 않습니다");
    }
    public static synchronized void startTest(String id){
        if(runDir==null)throw new IllegalStateException("시나리오 실행 기록이 없습니다");
        testId=id;testStarted=System.currentTimeMillis();
        manualStatus="";manualNote="";
        testDir=new File(runDir,"tests/"+id);testDir.mkdirs();
        ScenarioCatalog.Item t=ScenarioCatalog.test(id);
        try{
            JSONObject x=new JSONObject().put("id",id).put("title",t.title).put("evidenceRequired",t.evidence).put("startedMs",testStarted);
            write(new File(testDir,"test.json"),x.toString(2));
        }catch(Exception ignored){}
        log("TEST_START",id+" "+t.title+" | 기준: "+t.evidence);
    }
    public static synchronized void markManual(String status,String evidence) {
        if(testId.isEmpty()) {log("MANUAL_IGNORED","현재 실행 중인 기능시험이 없습니다");return;}
        manualStatus=status;manualNote=evidence;
        log("MANUAL_CHECK",status+" - "+evidence+" [사용자가 입력한 현장 확인; 자동 증거와 분리]");
    }
    public static synchronized String manualStatus(){return manualStatus;}
    public static synchronized String manualNote(){return manualNote;}
    public static synchronized void log(String kind,String message) {
        JSONObject entry=new JSONObject();
        try{
            entry.put("ts",System.currentTimeMillis());entry.put("time",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.KOREA).format(new Date()));
            entry.put("type",kind).put("runId",runId).put("scenarioId",scenarioId).put("testId",testId).put("message",message);
            String line=entry.toString()+"\n";
            if(allLog!=null)append(allLog,line);
            if(runDir!=null)append(new File(runDir,"events.jsonl"),line);
            if(testDir!=null)append(new File(testDir,"events.jsonl"),line);
        }catch(Exception e){Log.w(TAG,"Write failed",e);}
    }
    public static synchronized void transcript(String direction,String id,String sentence,boolean background) {
        if(runDir==null||sentence==null||sentence.isEmpty())return;
        try{
            JSONObject j=new JSONObject().put("timestampMs",System.currentTimeMillis()).put("direction",direction)
                .put("viewId",id).put("text",sentence).put("background",background);
            String line=j.toString()+"\n";
            append(new File(runDir,"transcripts.jsonl"),line);
            if(testDir!=null)append(new File(testDir,"transcripts.jsonl"),line);
        }catch(Exception e){log("TRANSCRIPT_WRITE_ERROR",e.toString());}
    }
    public static synchronized File captureXml(String label,String xml) {
        if(runDir==null||xml==null)return null;
        try{
            File dest=testDir==null?runDir:testDir;
            File out=new File(dest,"screens/"+String.format(Locale.US,"%06d",screenCounter++)+"_"+label.replaceAll("[^a-zA-Z0-9_-]","_")+".xml");
            out.getParentFile().mkdirs();write(out,xml);
            log("SCREEN_XML","전체 화면 계층 저장: "+out.getName()+" / "+xml.length()+"자");return out;
        }catch(Exception e){log("SCREEN_XML_ERROR",e.toString());return null;}
    }
    public static synchronized File screenshotFile(String label) {
        if(runDir==null)return null;
        File dest=testDir==null?runDir:testDir;
        File out=new File(dest,"screens/"+String.format(Locale.US,"%06d",screenCounter++)+"_"+label.replaceAll("[^a-zA-Z0-9_-]","_")+".png");
        out.getParentFile().mkdirs();return out;
    }
    public static synchronized void finishTest(Context context,String verdict,String reason,JSONObject evidence) {
        if(testDir==null)return;
        String id=testId;
        try{
            JSONObject result=new JSONObject().put("id",id).put("title",ScenarioCatalog.test(id).title).put("verdict",verdict)
                .put("reason",reason).put("startedMs",testStarted).put("finishedMs",System.currentTimeMillis())
                .put("evidence",evidence==null?new JSONObject():evidence).put("manualStatus",manualStatus).put("manualNote",manualNote)
                .put("source",ScenarioCatalog.source());
            write(new File(testDir,"result.json"),result.toString(2));
            outcomes.put(id,result);
            log("TEST_END",id+" "+verdict+" | "+reason);
            // Flow v4: legacy probe IDs are internal checkpoints, not 34 separate button executions.
            // Individual checkpoint result.json remains in the single W/I workflow ZIP.
            if(!"flow".equals(runMode)&&!"isolated".equals(runMode)){
                String name="HITEL_"+id+"_"+runId+".zip";
                exportZip(context,name,testDir);lastExport="Download/"+name;
                log("TEST_SAVED","내부 기능시험 ZIP: Download/"+name);
            }
        }catch(Exception e){log("EXPORT_ERROR",id+": "+e);}
        testDir=null;testId="";manualStatus="";manualNote="";
    }
    public static synchronized void saveFlowStep(int index,int count,String text,String action,String verdict,String reason) {
        if(runDir==null)return;
        try{
            JSONObject j=new JSONObject().put("index",index+1).put("total",count)
                .put("step",text).put("action",action).put("verdict",verdict)
                .put("reason",reason).put("timestamp",System.currentTimeMillis());
            File dest=new File(runDir,"steps/step_"+String.format(Locale.US,"%02d",index+1)+".json");
            write(dest,j.toString(2));
            log("FLOW_STEP_END",(index+1)+"/"+count+" "+verdict+" "+reason);
        }catch(Exception e){log("STEP_FILE_ERROR",e.toString());}
    }
    public static synchronized void finishRun(Context context, String reason) {
        if(runDir==null)return;
        String choice=scenarioId.isEmpty()?"SINGLE":scenarioId;
        log("RUN_END",reason);
        try{
            JSONArray list=new JSONArray();for(JSONObject r:outcomes.values())list.put(r);
            JSONObject j=new JSONObject().put("runId",runId).put("scenarioId",scenarioId).put("startedMs",runStarted)
                    .put("finishedMs",System.currentTimeMillis()).put("reason",reason).put("testResults",list)
                    .put("source",ScenarioCatalog.source());
            write(new File(runDir,"summary.json"),j.toString(2));
            write(new File(runDir,"README.txt"),"HITEL 통화 기능 시나리오 검증 결과\n"+
                    "이 압축 파일은 실행된 실제 이벤트/화면/결과를 저장합니다.\n"+
                    "이 파일은 W01~W08 또는 I01~I06 각 버튼별 독립 결과입니다.\n"+
                    "내부 기술 체크포인트는 tests/Txx/result.json 및 steps/step_NN.json으로 저장됩니다.\n"+
                    "PASS 자동검증과 MANUAL_CHECK 사용자의 현장 확인은 서로 구분합니다.\n"+
                    "UNVERIFIED = 가능성 또는 관찰은 있으나 합격 기준 미입증.\n"+
                    "NOT_TESTED = 필요한 통화/권한/증거가 없어 실행하지 못함.\n"+
                    "UNSUPPORTED = 시스템 제한 또는 미구현 경로.\n"+
                    "발화·화면 개인정보가 포함될 수 있습니다. 사용자가 직접 공유하기 전까지 로컬에만 보관합니다.\n");
            String name="HITEL_TEST_"+choice+"_"+runId+".zip";
            exportZip(context,name,runDir);lastExport="Download/"+name;
            context.getSharedPreferences("lab",Context.MODE_PRIVATE).edit().putString("last_export",lastExport).apply();
            log("RUN_SAVED","시나리오 통합 결과: "+lastExport);
        }catch(Exception e){log("RUN_EXPORT_ERROR",e.toString());}
        testDir=null;runDir=null;testId="";scenarioId="";runId="";runMode="";outcomes.clear();
    }
    public static synchronized boolean checkDownloadsWritable(Context context) {
        Uri uri=null;
        try {
            ContentResolver resolver=context.getContentResolver();
            ContentValues values=new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME,"HITEL_TEST_WRITE_"+stamp()+".txt");
            values.put(MediaStore.Downloads.MIME_TYPE,"text/plain");
            values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/");
            values.put(MediaStore.Downloads.IS_PENDING,1);
            uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("MediaStore insert null");
            try(OutputStream o=resolver.openOutputStream(uri)){
                if(o==null)throw new IOException("MediaStore openOutputStream null");
                o.write("HITEL_STORAGE_WRITE_OK".getBytes(StandardCharsets.UTF_8));
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);
            resolver.update(uri,ready,null,null);
            byte[] data=new byte[64];int count;
            try(InputStream in=resolver.openInputStream(uri)){
                if(in==null)throw new IOException("MediaStore openInputStream null");
                count=in.read(data);
            }
            boolean ok=count>0&&new String(data,0,count,StandardCharsets.UTF_8).contains("HITEL_STORAGE_WRITE_OK");
            log("MEDIASTORE_PROBE",ok?"Downloads 파일 쓰기/재열기 성공":"Downloads 파일 내용 검증 불일치");
            return ok;
        }catch(Exception e){log("MEDIASTORE_PROBE_ERROR",e.toString());return false;}
        finally{if(uri!=null)try{context.getContentResolver().delete(uri,null,null);}catch(Exception ignored){}}
    }
    public static synchronized String exportHistory(Context c) {
        init(c);String n="HITEL_ALL_LOGS_"+stamp()+".zip";
        File hist=new File(root,"history_for_export");hist.mkdirs();
        try{
            copy(allLog,new File(hist,"all_events.jsonl"));
            write(new File(hist,"README.txt"),"전체 누적 로그. 화면에 표시되는 로그와 동일한 원본이며 중간 생략이나 최대 행 제한이 없습니다.\n");
            exportZip(c,n,hist);return "Download/"+n;
        }catch(Exception e){return "저장 실패: "+e;}
    }
    private static void exportZip(Context c,String filename,File source) throws Exception {
        ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,filename);
        cv.put(MediaStore.Downloads.MIME_TYPE,"application/zip");
        cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/");cv.put(MediaStore.Downloads.IS_PENDING,1);
        ContentResolver resolver=c.getContentResolver();
        Uri uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
        if(uri==null)throw new IOException("MediaStore insert returned null");
        try(OutputStream stream=resolver.openOutputStream(uri);ZipOutputStream zip=new ZipOutputStream(stream)){
            addToZip(zip,source,source);
        }catch(Exception e){resolver.delete(uri,null,null);throw e;}
        ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);resolver.update(uri,ready,null,null);
    }
    private static void addToZip(ZipOutputStream zip,File base,File source)throws IOException{
        if(source.isDirectory()){File[] files=source.listFiles();if(files!=null)for(File f:files)addToZip(zip,base,f);return;}
        String name=base.toPath().relativize(source.toPath()).toString().replace('\\','/');
        zip.putNextEntry(new ZipEntry(name));
        try(InputStream in=new FileInputStream(source)){byte[] buf=new byte[32768];int n;while((n=in.read(buf))!=-1)zip.write(buf,0,n);}
        zip.closeEntry();
    }
    private static void copy(File from,File to)throws IOException{
        try(InputStream in=new FileInputStream(from);OutputStream out=new FileOutputStream(to)){
            byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
        }
    }
    private static void append(File file,String content)throws IOException {
        file.getParentFile().mkdirs();
        try(FileOutputStream f=new FileOutputStream(file,true)){f.write(content.getBytes(StandardCharsets.UTF_8));}
    }
    private static void write(File file,String content)throws IOException {
        file.getParentFile().mkdirs();
        try(FileOutputStream f=new FileOutputStream(file)){f.write(content.getBytes(StandardCharsets.UTF_8));}
    }
}
