plugins { id("com.android.application") }
android {
    namespace = "app.hitel.samsungprobe"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.hitel.callflowlab.v4"
        minSdk = 33
        targetSdk = 33
        versionCode = 4
        versionName = "0.4.0-flow-lab"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
