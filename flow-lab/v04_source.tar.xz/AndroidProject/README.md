# HITEL Call FlowLab v0.4 — 8 workflows + 6 isolated checks

이 APK는 실제 원본 삼성·SKT 앱의 동작 조건을 테스트하는 **진단 프로그램**입니다. 제조사 시스템의 비공개 통화 오디오 API를 획득하거나 기본 전화 앱을 변경하지 않습니다.

- W01~W08: v4 문서에 확정된 단계 순서대로 실행하는 8개 통합 흐름
- I01~I06: 통화 없이 또는 단독으로 실행 가능한 6개 독립 기능 점검
- D/F/S/X 41개 사용 사례: 실행 버튼이 아닌 흐름의 사례 참조
- T01~T34: 별도 버튼 없는 기술 검증 체크포인트; T15 수어 인식은 후속 개발, T18 결과 저장은 공통 검사
- 14개 버튼 각각 독립 `Download/HITEL_TEST_<W/I>_<timestamp>.zip` 자동 내보내기
- ZIP 내부: `run.json`, `flow.json`, `summary.json`, `steps/step_XX.json`, `tests/Txx/result.json`, `events.jsonl`, `transcripts.jsonl`, `screens/*.xml`, 가능한 `screens/*.png`.
- 모든 이벤트는 앱 내부 `all_events.jsonl`에 제한 없이 추가 저장; 화면의 전체 로그에서 과거 행까지 스크롤, 자동 따라가기 ON/OFF 지원.
- W03 STT 인식 후 이용자가 앱에서 직접 문장을 확인·수정·승인해야 T07 전송을 시도합니다. 허가되지 않은 자동 통화 발신/수신 없음.
- W01/W02/W03의 실제 문자·합성음 송출 시도는 시작 전 사용자에게 안내합니다.
- 상태: PASS / FAIL / UNSUPPORTED / NOT_TESTED / UNVERIFIED. 클릭 성공만으로 상대방 청취 성공 처리하지 않습니다.
- WebRTC 자동 라우팅 기능은 전혀 구현/수정하지 않습니다.

## 검증 게이트
1. Android CI 컴파일 성공 + APK 내용·서명 구조 검사.
2. 실제 전화기의 설치 및 테스트는 사용자 기기 결과 ZIP 업로드로만 검증할 수 있습니다. APK 빌드 성공은 해당 전화 기능 성공이 아닙니다.
