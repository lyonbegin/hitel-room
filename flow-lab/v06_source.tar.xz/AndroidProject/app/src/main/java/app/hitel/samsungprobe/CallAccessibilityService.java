package app.hitel.samsungprobe;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;

/** Read Samsung OEM's actually exposed accessibility tree; no gesture coordinates. */
public class CallAccessibilityService extends AccessibilityService {
    public static volatile CallAccessibilityService instance;
    private static volatile boolean consoleRequested=false;
    private WindowManager overlayManager;
    private View overlayView;
    private boolean overlayShown=false;
    public static void setConsoleRequested(boolean value){
        consoleRequested=value;
        CallAccessibilityService current=instance;
        if(current!=null)current.main.post(current::updateOverlay);
    }
    private boolean samsungWindowOnTop(){
        AccessibilityNodeInfo active=getRootInActiveWindow();
        String pkg=active==null?"":s(active.getPackageName());
        return pkg.startsWith("com.samsung.android.incallui")||
            pkg.startsWith("com.samsung.android.dialer")||
            pkg.startsWith("com.samsung.android.app.telephonyui");
    }
    /** Permission-free TYPE_ACCESSIBILITY_OVERLAY is used only for enabled
     *  accessibility services. This is a return control, not hidden OS UI scraping. */
    private void updateOverlay(){
        try{
            boolean want=consoleRequested&&LabStore.running()&&"W03".equals(LabStore.currentScenario())&&samsungWindowOnTop();
            if(want==overlayShown)return;
            if(want){
                overlayManager=(WindowManager)getSystemService(WINDOW_SERVICE);
                Button b=new Button(this);b.setAllCaps(false);b.setText("HITEL로 돌아오기");
                b.setTextSize(12);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffeeeeee));
                b.setOnClickListener(v->{
                    LabStore.log("HITEL_OVERLAY_RETURN","사용자가 삼성 전화 화면 위의 반환 버튼을 누름");
                    Intent i=new Intent(this,W03ConsoleActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    try{startActivity(i);}catch(Throwable e){LabStore.log("HITEL_OVERLAY_RETURN_ERROR",e.toString());}
                });
                WindowManager.LayoutParams p=new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
                p.gravity=Gravity.TOP|Gravity.END;p.x=12;p.y=115;
                overlayManager.addView(b,p);overlayView=b;overlayShown=true;
                LabStore.log("HITEL_OVERLAY_SHOWN","삼성 화면 위에 반환 버튼 표시. 사용자가 눌러 HITEL 전면 복귀");
            }else hideOverlay();
        }catch(Throwable e){LabStore.log("HITEL_OVERLAY_ERROR",e.toString());hideOverlay();}
    }
    private void hideOverlay(){
        if(overlayView!=null&&overlayManager!=null){
            try{overlayManager.removeView(overlayView);}catch(Throwable ignored){}
        }
        overlayView=null;overlayShown=false;
    }

    private static final String P="com.samsung.android.incallui:id/";
    private static final String[] TRACKED={
        "text_call_message_edit_text","text_call_submit_button","text_call_message_list_recycler_view",
        "text_call_main","bixby_text_call_floating_button_container","in_call_text_call_container",
        "ai_call_assist_button","live_translate_button","translation_call_message_list_recycler_view",
        "translation_text_call_main","switch_to_voice_call_container","end_translate_container",
        "remote_message","local_message","remote_message_translated","local_message_translated",
        "screen_call_container","accept_as_text_call"
    };
    public static final class Snapshot {
        public final Set<String> ids=new HashSet<>();
        public final Set<String> pkgs=new HashSet<>();
        public long scannedAt;
        public String foregroundPackage="";
        public boolean textCall,translated,localTextPresent;
        public int remoteCount,localCount,translatedCount,remoteBackgroundCount;
        public String lastRemote="",lastLocal="",lastTranslated="";
        public long lastRemoteAt;
        public Snapshot copy(){
            Snapshot b=new Snapshot();b.ids.addAll(ids);b.pkgs.addAll(pkgs);b.scannedAt=scannedAt;
            b.foregroundPackage=foregroundPackage;b.textCall=textCall;b.translated=translated;b.localTextPresent=localTextPresent;
            b.remoteCount=remoteCount;b.localCount=localCount;b.translatedCount=translatedCount;
            b.remoteBackgroundCount=remoteBackgroundCount;b.lastRemote=lastRemote;b.lastLocal=lastLocal;b.lastTranslated=lastTranslated;return b;
        }
    }
    private final Object lock=new Object();
    private final Snapshot state=new Snapshot();
    private final Set<String> seenTexts=new HashSet<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private long lastSweep,lastCapture;
    private String lastSignature="";
    private boolean backgroundTrial;

    @Override protected void onServiceConnected(){
        super.onServiceConnected();instance=this;
        AccessibilityServiceInfo i=getServiceInfo();
        i.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        i.notificationTimeout=100;i.eventTypes=AccessibilityEvent.TYPES_ALL_MASK;setServiceInfo(i);
        LabStore.log("A11Y_SERVICE","연결됨. 실제 접근성 ID / 텍스트 / 컨텐츠 설명 사용");
        main.post(this::updateOverlay);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null)return;
        if(consoleRequested)updateOverlay();
        if(!LabStore.running())return;
        try{
            String pkg=s(event.getPackageName());
            if(!relevant(pkg))return;
            String val=event.getText()==null?"":event.getText().toString();
            LabStore.log("A11Y_EVENT","pkg="+pkg+" type="+AccessibilityEvent.eventTypeToString(event.getEventType())+
                    " class="+s(event.getClassName())+" text="+val);
            AccessibilityNodeInfo source=event.getSource();
            if(source!=null&&pkg.equals("com.samsung.android.incallui")){
                boolean bg=!"com.samsung.android.incallui".equals(activePkg());
                harvest(source,bg,0,new int[]{0});
            }
            if(SystemClock.elapsedRealtime()-lastSweep>1300){lastSweep=SystemClock.elapsedRealtime();scanNow("event");}
        }catch(Throwable e){LabStore.log("A11Y_ERROR",e.toString());}
    }
    public void resetEvidence(){
        synchronized(lock){state.ids.clear();state.pkgs.clear();state.scannedAt=0;
            state.remoteCount=state.localCount=state.translatedCount=state.remoteBackgroundCount=0;
            state.lastRemote=state.lastLocal=state.lastTranslated="";state.lastRemoteAt=0;state.textCall=state.translated=state.localTextPresent=false;
            seenTexts.clear();lastSignature="";backgroundTrial=false;}
        scanAsync("reset");
    }
    public Snapshot snapshot(){synchronized(lock){return state.copy();}}
    private void scanAsync(String reason){main.post(()->scanNow(reason));}
    public void scanBlocking(String reason){
        if(Looper.myLooper()==Looper.getMainLooper()){scanNow(reason);return;}
        CountDownLatch latch=new CountDownLatch(1);
        main.post(()->{try{scanNow(reason);}finally{latch.countDown();}});
        try{latch.await(4,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    private String activePkg(){AccessibilityNodeInfo x=getRootInActiveWindow();return x==null?"":s(x.getPackageName());}
    private static boolean relevant(String p){return p.contains("incall")||p.contains("dialer")||p.contains("callassistant")||p.contains("telephonyui")||p.contains("samsungprobe")||p.startsWith("app.hitel.callflowlab");}
    private void scanNow(String reason){
        if(!LabStore.running())return;
        try{
            List<AccessibilityNodeInfo> roots=new ArrayList<>();
            List<AccessibilityWindowInfo> windows=getWindows();
            if(windows!=null)for(AccessibilityWindowInfo w:windows){AccessibilityNodeInfo x=w.getRoot();if(x!=null&&relevant(s(x.getPackageName())))roots.add(x);}
            if(roots.isEmpty()){AccessibilityNodeInfo x=getRootInActiveWindow();if(x!=null)roots.add(x);}
            String active=activePkg();
            synchronized(lock){state.foregroundPackage=active;state.scannedAt=System.currentTimeMillis();}
            for(AccessibilityNodeInfo root:roots){
                String pkg=s(root.getPackageName());if(!relevant(pkg))continue;
                StringBuilder xml=new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<window package=\""+esc(pkg)+"\" reason=\""+esc(reason)+"\">\n");
                StringBuilder sig=new StringBuilder(pkg);
                render(root,xml,sig,0,new int[]{0},false);
                xml.append("</window>\n");
                String hash=Integer.toHexString(sig.toString().hashCode());
                if(!hash.equals(lastSignature)||reason.startsWith("start")||reason.startsWith("end")||reason.equals("manual")){
                    lastSignature=hash;LabStore.captureXml(reason,xml.toString());
                }
            }
        }catch(Throwable e){LabStore.log("A11Y_SCAN_ERROR",e.toString());}
    }
    private void render(AccessibilityNodeInfo node,StringBuilder xml,StringBuilder signature,int depth,int[] traversed,boolean bg){
        if(node==null||depth>38||traversed[0]++>20000)return;
        String id=s(node.getViewIdResourceName()),txt=s(node.getText()),desc=s(node.getContentDescription());
        String cls=s(node.getClassName());
        synchronized(lock){
            if(!id.isEmpty()){state.ids.add(id);signature.append('|').append(id);}
            if(!txt.isEmpty())signature.append("{TEXT}").append(txt);
            state.pkgs.add(s(node.getPackageName()));
            if(id.equals(P+"text_call_message_edit_text")){state.textCall=true;state.localTextPresent=!txt.isEmpty();}
            if(id.equals(P+"translation_call_message_list_recycler_view"))state.translated=true;
        }
        if(isTranscript(id)&&!txt.isEmpty())captureTranscript(id,txt,bg);
        xml.append("  ".repeat(Math.min(depth+1,40))).append("<node class=\"").append(esc(cls)).append("\" id=\"")
          .append(esc(id)).append("\" text=\"").append(esc(txt)).append("\" desc=\"").append(esc(desc))
          .append("\" enabled=\"").append(node.isEnabled()).append("\" clickable=\"").append(node.isClickable())
          .append("\" editable=\"").append(node.isEditable()).append("\" children=\"").append(node.getChildCount()).append("\">\n");
        for(int i=0;i<node.getChildCount();i++)render(node.getChild(i),xml,signature,depth+1,traversed,bg);
        xml.append("  ".repeat(Math.min(depth+1,40))).append("</node>\n");
    }
    private void harvest(AccessibilityNodeInfo n,boolean bg,int depth,int[] counter){
        if(n==null||depth>36||counter[0]++>12000)return;
        String id=s(n.getViewIdResourceName()),txt=s(n.getText());
        if(isTranscript(id)&&!txt.isEmpty())captureTranscript(id,txt,bg);
        for(int i=0;i<n.getChildCount();i++)harvest(n.getChild(i),bg,depth+1,counter);
    }
    private static boolean isTranscript(String id){return id.equals(P+"remote_message")||id.equals(P+"local_message")||id.equals(P+"remote_message_translated")||id.equals(P+"local_message_translated");}
    private void captureTranscript(String id,String txt,boolean background){
        String key=id+"\n"+txt;
        synchronized(lock){
            if(!seenTexts.add(key))return;
            if(id.endsWith("/remote_message")){state.remoteCount++;state.lastRemote=txt;state.lastRemoteAt=System.currentTimeMillis();if(background)state.remoteBackgroundCount++;}
            else if(id.endsWith("/local_message")){state.localCount++;state.lastLocal=txt;}
            else {state.translatedCount++;state.lastTranslated=txt;}
        }
        String direction=id.contains("remote_")?"remote":"local";
        LabStore.transcript(direction,id,txt,background);
        LabStore.log(background?"TRANSCRIPT_BACKGROUND":"TRANSCRIPT",id+" " +txt);
    }
    public void setBackgroundTrial(boolean on){synchronized(lock){backgroundTrial=on;}LabStore.log("BACKGROUND",on?"백그라운드 시험 시작":"백그라운드 시험 종료");}
    public boolean home(){return performGlobalAction(GLOBAL_ACTION_HOME);}
    public void captureScreenshot(String reason){
        File file=LabStore.screenshotFile(reason);if(file==null)return;
        try{
            takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                @Override public void onSuccess(ScreenshotResult result){
                    try{
                        HardwareBuffer hb=result.getHardwareBuffer(); Bitmap b=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                        if(b==null)throw new IllegalStateException("Bitmap inaccessible");
                        Bitmap copy=b.copy(Bitmap.Config.ARGB_8888,false);
                        try(FileOutputStream out=new FileOutputStream(file)){copy.compress(Bitmap.CompressFormat.PNG,100,out);}
                        copy.recycle();b.recycle();hb.close();LabStore.log("SCREEN_PNG","저장: "+file.getName());
                    }catch(Throwable e){LabStore.log("SCREENSHOT_ERROR",e.toString());}
                }
                @Override public void onFailure(int code){LabStore.log("SCREENSHOT_UNAVAILABLE","OS blocked screenshot error="+code);}
            });
        }catch(Throwable e){LabStore.log("SCREENSHOT_UNAVAILABLE",e.toString());}
    }
    private static String s(CharSequence x){return x==null?"":x.toString();}
    private static String esc(String s){return s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;").replace("'","&apos;");}
    private AccessibilityNodeInfo find(String fullId){
        List<AccessibilityWindowInfo> wins=getWindows();
        if(wins!=null)for(AccessibilityWindowInfo w:wins){AccessibilityNodeInfo root=w.getRoot();if(root==null)continue;
            List<AccessibilityNodeInfo> got=root.findAccessibilityNodeInfosByViewId(fullId);if(got!=null&&!got.isEmpty())return got.get(0);
        }
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null)return null;List<AccessibilityNodeInfo> got=root.findAccessibilityNodeInfosByViewId(fullId);
        return got==null||got.isEmpty()?null:got.get(0);
    }
    private static boolean click(AccessibilityNodeInfo n){for(int i=0;n!=null&&i<9;n=n.getParent())if(n.isClickable()&&n.isEnabled())return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);return false;}
    public boolean enterTextCall(){
        if(find(P+"text_call_message_edit_text")!=null)return true;
        for(String name:new String[]{"in_call_text_call_container","bixby_text_call_floating_button_container","ai_call_assist_button","upgrade_to_bixby_text_call_button"}){
            AccessibilityNodeInfo n=find(P+name);
            if(n!=null){boolean ok=click(n);LabStore.log("ACTION_CLICK","텍스트 통화 진입: "+name+" → "+ok);return ok;}
        }
        LabStore.log("ACTION_UNAVAILABLE","텍스트 통화 진입에 사용할 수 있는 접근성 노드 없음");return false;
    }
    /** Check a LIVE node. The historic Snapshot.textCall boolean is latched and
     *  cannot establish that Samsung Text Call is still visible now. */
    public boolean isTextCallVisible(){return find(P+"text_call_message_edit_text")!=null;}
    /** Only used after an explicit user selection. Never changes call mode by itself. */
    public boolean switchToVoiceCall(){
        AccessibilityNodeInfo n=find(P+"switch_to_voice_call_container");
        if(n==null)n=find(P+"resume_call_button");
        if(n==null){LabStore.log("VOICE_SWITCH_NODE_MISSING","삼성 일반 음성 전환 컨트롤 노드 미발견");return false;}
        boolean ok=click(n);LabStore.log("VOICE_SWITCH_ACTION","사용자 요청에 의한 삼성 음성 전환 클릭="+ok);return ok;
    }
    /** OEM's own input-to-TTS button, no carrier-audio injection. The old version
     *  required edit + submit nodes at the same instant before typing; here each
     *  node gets its own observed result and we re-read the changed hierarchy. */
    public boolean putAndSend(String value) {
        if(value==null||value.isBlank())return false;
        AccessibilityNodeInfo input=null;
        for(int attempt=0;attempt<8;attempt++){
            input=find(P+"text_call_message_edit_text");
            AccessibilityNodeInfo candidate=find(P+"text_call_submit_button");
            LabStore.log("OEM_INPUT_NODE_CHECK","attempt="+attempt+" input="+(input!=null)+
                " inputEnabled="+(input!=null&&input.isEnabled())+" inputEditable="+(input!=null&&input.isEditable())+
                " send="+(candidate!=null)+" sendEnabled="+(candidate!=null&&candidate.isEnabled()));
            if(input!=null&&input.isEnabled())break;
            if(attempt==2)enterTextCall();
            try{Thread.sleep(650);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
        }
        if(input==null){LabStore.log("OEM_INPUT_NOT_FOUND","실제 삼성 Text Call 입력 노드가 화면에 없음");return false;}
        Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        boolean set=input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
        AccessibilityNodeInfo verify=find(P+"text_call_message_edit_text");
        boolean filled=verify!=null&&value.equals(s(verify.getText()));
        LabStore.log("OEM_INPUT_SET_RESULT","set="+set+" valueReadback="+filled+" / length="+value.length());
        if(!set||!filled)return false;
        AccessibilityNodeInfo send=null;
        for(int attempt=0;attempt<8;attempt++){
            send=find(P+"text_call_submit_button");
            LabStore.log("OEM_SEND_NODE_CHECK","attempt="+attempt+" send="+(send!=null)+" enabled="+(send!=null&&send.isEnabled()));
            if(send!=null&&send.isEnabled())break;
            try{Thread.sleep(450);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
        }
        if(send==null){LabStore.log("OEM_SEND_NOT_FOUND","삼성 TTS 전송 버튼을 찾을 수 없음, 임의 화면 좌표 클릭하지 않음");return false;}
        boolean clicked=click(send);
        LabStore.log("OEM_SEND_BUTTON_ACTION","text_call_submit_button clicked="+clicked+" / peer TTS delivery not proven");
        return clicked;
    }
    @Override public void onInterrupt(){LabStore.log("A11Y_INTERRUPT","접근성 서비스 중단");}
    @Override public void onDestroy(){hideOverlay();consoleRequested=false;instance=null;LabStore.log("A11Y_DESTROY","접근성 서비스 종료");super.onDestroy();}
}
