plugins { id("com.android.application") }
android {
    namespace = "app.hitel.samsungprobe"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.hitel.callflowlab.v6"
        minSdk = 33
        targetSdk = 33
        versionCode = 6
        versionName = "0.6.0-foreground-console"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
