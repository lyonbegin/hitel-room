# HITEL W03 v0.6 foreground console

## Implemented
- W03 is now a single native Android Activity: `W03ConsoleActivity`. One screen contains call state, dialing, Samsung Text Call preparation, last actually observed captions, live speech recognition, editable text, OEM TTS, SMS composer, explicit direct-voice switch, peer confirmation, full scrolling logs and ZIP save.
- The Samsung default dialer remains unchanged. Calls are placed only by the user after confirmation and `CALL_PHONE` permission. `ACTION_CALL` may temporarily bring Samsung UI to the foreground.
- A floating `TYPE_ACCESSIBILITY_OVERLAY` **HITEL로 돌아오기** button appears while the Samsung phone window is active, and returns to the W03 controller on direct user tap. Accessible OEM controls are inspected and activated while they are available on-screen.
- Samsung/OEM background **hidden** UI is not assumed to be inspectable. `getWindows()` covers interactive windows; A11Y events are logged when actually received; the panel distinguishes previously captured subtitles from new live data.
- OEM TTS success requires peer confirmation, not a click on submit. The result is stored separately with manual evidence metadata.
- Existing W01 W02 W04-W08 and I01-I06 remain. v0.5 untouched on distinct package name.

## Limitations, deliberately not misrepresented
- AOSP does not grant normal third-party apps arbitrary capture/injection of PSTN call audio.
- Samsung Text Call input/control while its window is hidden behind the HITEL Activity is not guaranteed; brief foreground OEM screen is needed for sensitive UI operations.
- After a native phone UI is opened, returning to the HITEL screen uses a user tap on the accessibility overlay. Automatic background activity launch is not guaranteed by Android.
- Real call STT and remote TTS delivery remain real-device tests; APK compilation is not runtime proof.
