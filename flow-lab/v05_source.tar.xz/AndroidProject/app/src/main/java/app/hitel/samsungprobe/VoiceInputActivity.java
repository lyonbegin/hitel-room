package app.hitel.samsungprobe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.telecom.TelecomManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

/** Foreground voice input for an already ongoing carrier Text Call.
 *  Recognition produces a confirmed text draft; it does not capture remote audio
 *  and does not inject audio into a carrier call. */
public final class VoiceInputActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String[] languages={"한국어 (ko-KR)","English (en-US)","中文 (zh-CN)","日本語 (ja-JP)"};
    private final String[] languageTags={"ko-KR","en-US","zh-CN","ja-JP"};
    private SpeechRecognizer recognizer;
    private EditText transcript;
    private TextView status;
    private Spinner language;
    private Button listen,stop;
    private boolean recognitionCompleted=false,recognitionBusy=false,submitted=false;
    private String recognizedOriginal="",sttError="",recognitionLang="ko-KR";
    private final Runnable statusPoll=new Runnable(){
        @Override public void run(){
            if(isFinishing())return;
            if(!ScenarioEngineService.active||!"W03".equals(ScenarioEngineService.currentScenario)){
                status.setText("W03 흐름이 실행 중이지 않습니다. W03 버튼으로 시험을 시작해 주십시오.");
            }else if(ScenarioEngineService.awaitingVoiceInput){
                if(!recognitionBusy&&recognizer==null&&!recognitionCompleted)
                    status.setText("W03 준비 완료 · 이 별도 화면에서 '음성 인식 시작'을 누르십시오. 통화 상대방의 목소리는 캡처하지 않습니다.");
            }else if(!submitted){
                status.setText("전화 연결 및 삼성 문자통화 준비 중입니다. 음성 입력 준비 단계에 도달하면 아래 버튼을 사용할 수 있습니다.");
            }
            handler.postDelayed(this,650);
        }
    };
    private int dp(float d){return (int)(d*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String t,int sp){TextView v=new TextView(this);v.setText(t);v.setTextColor(Color.BLACK);v.setTextSize(sp);v.setPadding(dp(4),dp(7),dp(4),dp(6));return v;}
    private Button button(String s,Runnable cb){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextSize(13);b.setOnClickListener(v->cb.run());return b;}
    private void log(String type,String text){LabStore.log(type,text);}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override public void onCreate(Bundle b){
        super.onCreate(b);LabStore.init(this);
        ScrollView sc=new ScrollView(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15),dp(13),dp(15),dp(12));box.setBackgroundColor(Color.WHITE);sc.addView(box);
        box.addView(label("W03 · 별도 음성 입력",22));
        box.addView(label("삼성 문자통화 도중 이 화면으로 이동해 본인의 목소리만 인식합니다. 전화 연결 및 삼성 문자통화의 유지 여부는 검사 로그로 확인합니다.",13));
        status=label("준비 확인 중",12);status.setBackgroundColor(0xffeeeeee);box.addView(status);
        box.addView(label("음성 인식 언어",14));
        language=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,languages);
        language.setAdapter(adapter);box.addView(language);
        LinearLayout listenRow=new LinearLayout(this);
        listen=button("🎙 음성 인식 시작",this::startRecognition);
        stop=button("인식 중지",this::stopRecognition);
        listenRow.addView(listen,new LinearLayout.LayoutParams(0,dp(53),2));
        listenRow.addView(stop,new LinearLayout.LayoutParams(0,dp(53),1));box.addView(listenRow);
        box.addView(label("인식된 문장 · 직접 수정 가능",14));
        transcript=new EditText(this);transcript.setHint("인식 결과가 나오거나, 인식할 수 없다면 문장을 직접 입력하십시오.");
        transcript.setMinLines(3);transcript.setGravity(Gravity.TOP);transcript.setTextSize(17);
        box.addView(transcript,new LinearLayout.LayoutParams(-1,dp(124)));
        box.addView(label("아래 방식 중 하나를 선택하면 문장을 확정합니다. 상대방에게 실제로 보내는 작업은 각 방식의 권한·화면에 따라 별도로 검증합니다.",12));
        box.addView(button("삼성 문자통화 TTS로 전달 (기본)",()->chooseMode("oem_tts")));
        box.addView(button("문자로 보내기 · SMS 작성 화면 열기",()->chooseMode("sms")));
        box.addView(button("일반 음성통화로 돌아가서 직접 말하기",()->chooseMode("voice")));
        box.addView(button("삼성 통화 화면 보기 (입력은 유지)",this::openCallScreen));
        box.addView(button("이번 W03 음성 입력 취소",()->{
            if(ScenarioEngineService.awaitingVoiceInput){
                startService(new Intent(this,ScenarioEngineService.class).setAction(ScenarioEngineService.VOICE_CANCEL));
            }
            finish();
        }));
        setContentView(sc);log("VOICE_UI_OPEN","별도 음성 입력 Activity가 포그라운드에 열림 / W03="+ScenarioEngineService.currentScenario);
        handler.post(statusPoll);
    }
    private boolean ready(){
        if(!ScenarioEngineService.active||!ScenarioEngineService.awaitingVoiceInput){
            toast("W03이 음성 입력 단계에 도달할 때 실행해 주십시오.");return false;
        }
        return true;
    }
    private void startRecognition(){
        if(!ready())return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},501);return;
        }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){
            sttError="NO_RECOGNIZER";log("VOICE_STT_UNSUPPORTED","시스템 SpeechRecognizer 서비스 없음");
            status.setText("이 단말에 시스템 음성 인식기가 없습니다. 아래에 문장을 직접 입력할 수 있습니다.");return;
        }
        destroyRecognizer();
        recognitionCompleted=false;recognitionBusy=true;recognitionLang=languageTags[language.getSelectedItemPosition()];
        sttError="";recognizedOriginal="";
        try{
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle params){status.setText("마이크 준비됨 · 지금 말씀해 주십시오");log("VOICE_STT_READY","foreground=true language="+recognitionLang);}
                @Override public void onBeginningOfSpeech(){status.setText("발화 인식 중");log("VOICE_STT_BEGIN","사용자 발화 시작");}
                @Override public void onEndOfSpeech(){status.setText("인식 결과를 처리하는 중");log("VOICE_STT_END","사용자 발화 종료");}
                @Override public void onRmsChanged(float rms){}
                @Override public void onBufferReceived(byte[] data){}
                @Override public void onPartialResults(Bundle results){
                    ArrayList<String> pieces=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(pieces!=null&&!pieces.isEmpty())status.setText("인식 중: "+pieces.get(0));
                }
                @Override public void onResults(Bundle results){
                    recognitionBusy=false;recognitionCompleted=true;
                    ArrayList<String> list=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(list!=null&&!list.isEmpty()&&!list.get(0).isBlank()){
                        recognizedOriginal=list.get(0);transcript.setText(recognizedOriginal);
                        status.setText("인식 성공 · 문장을 수정하고 전송 방식을 고르십시오");
                        log("VOICE_STT_RESULT","recognition_language="+recognitionLang+" / transcript="+recognizedOriginal);
                    }else{
                        sttError="EMPTY_RESULTS";status.setText("인식 결과가 없습니다. 재시도 또는 직접 입력해 주십시오.");
                        log("VOICE_STT_EMPTY","음성인식 결과 비어 있음");
                    }
                    destroyRecognizer();
                }
                @Override public void onError(int error){
                    recognitionBusy=false;sttError=errorName(error)+"("+error+")";
                    status.setText("음성 인식 실패: "+sttError+" · 재시도하거나 직접 입력 가능");
                    log("VOICE_STT_ERROR","error="+sttError+" language="+recognitionLang+" call_mode="+ScenarioEngineService.currentState);
                    destroyRecognizer();
                }
                @Override public void onEvent(int e,Bundle params){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,recognitionLang);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
            status.setText("인식기 연결 중");recognizer.startListening(i);
            log("VOICE_STT_START","별도 포그라운드 Activity에서 인식 시작 language="+recognitionLang);
        }catch(Throwable e){recognitionBusy=false;sttError=e.toString();destroyRecognizer();
            log("VOICE_STT_EXCEPTION",sttError);status.setText("음성인식 시작 실패: "+e);
        }
    }
    private String errorName(int n){
        switch(n){
            case SpeechRecognizer.ERROR_NO_MATCH:return "ERROR_NO_MATCH";
            case SpeechRecognizer.ERROR_AUDIO:return "ERROR_AUDIO";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:return "ERROR_INSUFFICIENT_PERMISSIONS";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:return "ERROR_RECOGNIZER_BUSY";
            case SpeechRecognizer.ERROR_NETWORK:return "ERROR_NETWORK";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:return "ERROR_NETWORK_TIMEOUT";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:return "ERROR_SPEECH_TIMEOUT";
            case SpeechRecognizer.ERROR_SERVER:return "ERROR_SERVER";
            case SpeechRecognizer.ERROR_CLIENT:return "ERROR_CLIENT";
            default:return "CODE_"+n;
        }
    }
    private void stopRecognition(){
        if(recognizer!=null&&recognitionBusy){
            recognizer.stopListening();status.setText("발화 종료 요청 · 결과 인식을 확인하십시오");log("VOICE_STT_STOP","사용자가 인식 중지를 누름");
        }
    }
    private void destroyRecognizer(){
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Throwable ignored){}recognizer=null;}
    }
    private void chooseMode(String mode){
        if(!ready())return;
        final String value=transcript.getText().toString().trim();
        if(value.isEmpty()){toast("인식 결과 또는 직접 입력한 문장이 필요합니다.");return;}
        if(recognitionBusy){toast("인식 중지를 누르거나 결과가 완료된 뒤 선택해 주십시오.");return;}
        final String source=!recognizedOriginal.isBlank()?(recognizedOriginal.equals(value)?"STT":"STT_EDITED"):"MANUAL";
        String note;
        if("voice".equals(mode))note="일반 음성통화로 전환한 뒤 다시 직접 말씀하시는 방식입니다. 저장된 녹음 음성을 전화 회선에 주입하는 기능은 아닙니다.";
        else if("sms".equals(mode))note="SMS 문자 작성 화면을 열어 문장을 넣습니다. 이 동작은 통화 중 TTS가 아니며, 실제 문자 전송은 사용자가 직접 확인·실행합니다.";
        else note="삼성 문자통화로 돌아가 인식·확정한 문장을 입력하고 TTS 전송을 시도합니다. 실제 상대방 청취는 따로 확인합니다.";
        new AlertDialog.Builder(this).setTitle("문장 확정 및 전송 경로")
            .setMessage("문장: "+value+"\n\n"+note)
            .setNegativeButton("취소",null)
            .setPositiveButton("이 방식으로 진행",(d,w)->submit(mode,value,source)).show();
    }
    private void submit(String mode,String value,String source){
        submitted=true;
        Intent i=new Intent(this,ScenarioEngineService.class).setAction(ScenarioEngineService.VOICE_CHOICE)
            .putExtra("text",value).putExtra("mode",mode).putExtra("source",source)
            .putExtra("language",recognitionLang).putExtra("stt_error",sttError);
        try{startService(i);}catch(Throwable e){submitted=false;toast("전송 경로 확정 실패: "+e);return;}
        log("VOICE_UI_CONFIRMED","mode="+mode+" source="+source+" length="+value.length());
        if("sms".equals(mode)){
            try{Intent sms=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"));sms.putExtra("sms_body",value);startActivity(sms);
                log("SMS_COMPOSER_OPEN","SMS 작성 화면을 열었음. 자동 발신/자동 전송 없음");
            }catch(Throwable e){log("SMS_COMPOSER_ERROR",e.toString());toast("SMS 앱이 없거나 작성 화면을 열 수 없습니다");}
        }
        finish();
    }
    private void openCallScreen(){
        try{TelecomManager t=(TelecomManager)getSystemService(TELECOM_SERVICE);t.showInCallScreen(false);
            log("VOICE_UI_RETURN_CALL","삼성 통화 화면 보기 요청; 문자통화 → 일반 음성 모드 변경과는 별개");
        }catch(Throwable e){log("VOICE_UI_CALL_SCREEN_ERROR",e.toString());toast("통화 화면 복귀 불가: "+e);}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] perms,int[] grants){
        super.onRequestPermissionsResult(requestCode,perms,grants);
        if(requestCode==501){if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)startRecognition();
        else{sttError="MIC_PERMISSION_DENIED";status.setText("마이크 권한이 없습니다. 직접 문장을 입력하실 수 있습니다.");log("VOICE_MIC_DENIED","RECORD_AUDIO 권한 거부");}}
    }
    @Override protected void onDestroy(){handler.removeCallbacks(statusPoll);destroyRecognizer();super.onDestroy();}
}
