package app.hitel.samsungprobe;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Runtime manifest is generated from the exact v3 scenario specification. */
public final class ScenarioCatalog {
    public static final class Item {
        public final String id, group, title, details, evidence;
        public final List<String> tests;
        Item(String id,String group,String title,String details,String evidence,List<String> tests) {
            this.id=id;this.group=group;this.title=title;this.details=details;this.evidence=evidence;this.tests=tests;
        }
    }
    private static final Map<String,Item> scenarios=new LinkedHashMap<>();
    private static final Map<String,Item> tests=new LinkedHashMap<>();
    private static String catalogSource="";
    private ScenarioCatalog() {}
    public static synchronized void load(Context c) {
        if(!scenarios.isEmpty())return;
        try(InputStream in=c.getAssets().open("scenario_catalog_v3.json")) {
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
            JSONObject doc=new JSONObject(out.toString(StandardCharsets.UTF_8));
            catalogSource=doc.optString("source");
            JSONArray a=doc.getJSONArray("scenarios");
            for(int i=0;i<a.length();i++){
                JSONObject x=a.getJSONObject(i);List<String> linked=new ArrayList<>();
                JSONArray t=x.getJSONArray("tests");for(int k=0;k<t.length();k++)linked.add(t.getString(k));
                Item item=new Item(x.getString("id"),x.getString("group"),x.getString("title"),x.optString("details"),x.optString("passCriteria"),linked);
                scenarios.put(item.id,item);
            }
            a=doc.getJSONArray("tests");
            for(int i=0;i<a.length();i++){
                JSONObject x=a.getJSONObject(i);List<String> linked=new ArrayList<>();
                JSONArray s=x.getJSONArray("scenarios");for(int k=0;k<s.length();k++)linked.add(s.getString(k));
                Item item=new Item(x.getString("id"),"기능시험",x.getString("title"),"연결 시나리오: "+String.join(", ",linked),x.optString("evidence"),linked);
                tests.put(item.id,item);
            }
            if(scenarios.size()!=41||tests.size()!=34)throw new IllegalStateException("Expected 41/34, received "+scenarios.size()+"/"+tests.size());
        }catch(Exception e){throw new IllegalStateException("v3 시나리오 파일을 읽지 못했습니다",e);}
    }
    public static List<Item> scenarios(){return new ArrayList<>(scenarios.values());}
    public static List<Item> tests(){return new ArrayList<>(tests.values());}
    public static Item scenario(String id){return scenarios.get(id);}
    public static Item test(String id){return tests.get(id);}
    public static String source(){return catalogSource;}
}
