package app.hitel.samsungprobe;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Canonical v4 plans. The 41 user scenarios and 34 legacy probes are references,
 * NOT buttons. All 14 runnable paths are defined in the supplied v4 plan. */
public final class FlowCatalog {
    public static final class Plan {
        public final String id,title,criterion;
        public final boolean flow;
        public final List<String> steps=new ArrayList<>();
        public final List<String> scenarios=new ArrayList<>(), legacy=new ArrayList<>(), variants=new ArrayList<>();
        public final Map<Integer,String> actions=new LinkedHashMap<>();
        private Plan(JSONObject o,boolean flow) {
            id=o.optString("id");title=o.optString("title");criterion=o.optString("pass_gate");this.flow=flow;
            read(steps,o.optJSONArray("steps"));read(scenarios,o.optJSONArray("scenario_ids"));
            read(legacy,o.optJSONArray("legacy_tests"));read(variants,o.optJSONArray("variants"));
        }
        public JSONObject json(){
            JSONObject j=new JSONObject();try{
                j.put("id",id).put("title",title).put("kind",flow?"flow":"isolated")
                 .put("pass_gate",criterion).put("steps",new JSONArray(steps))
                 .put("scenario_ids",new JSONArray(scenarios)).put("legacy_tests",new JSONArray(legacy))
                 .put("variants",new JSONArray(variants));
            }catch(Exception ignored){}return j;
        }
    }
    private static final List<Plan> FLOWS=new ArrayList<>(),ISOLATED=new ArrayList<>();
    private static final Map<String,Plan> BY_ID=new LinkedHashMap<>();
    private static boolean loaded=false;
    private FlowCatalog(){}
    private static void read(List<String> dest,JSONArray a){if(a==null)return;for(int i=0;i<a.length();i++)dest.add(a.optString(i));}
    public static synchronized void load(Context ctx) {
        if(loaded)return;
        try(InputStream in=ctx.getAssets().open("flow_catalog_v4.json")){
            byte[] bytes=in.readAllBytes();JSONObject d=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
            loadArray(FLOWS,d.getJSONArray("flow_tests"),true);
            loadArray(ISOLATED,d.getJSONArray("isolated_tests"),false);
            if(FLOWS.size()!=8||ISOLATED.size()!=6)throw new IllegalStateException("v4 requires 8 flows and 6 isolated checks");
            loaded=true;
        }catch(Exception e){throw new IllegalStateException("Cannot open verified v4 catalog",e);}
    }
    private static void loadArray(List<Plan> dest,JSONArray array,boolean flow){
        for(int i=0;i<array.length();i++){
            Plan p=new Plan(array.optJSONObject(i),flow);if(p.id.isEmpty()||BY_ID.containsKey(p.id))throw new IllegalStateException("duplicate id");
            defineActions(p);dest.add(p);BY_ID.put(p.id,p);
        }
    }
    private static void set(Plan p,String csv){
        // One entry per exact v4 workflow step: empty means documented observation/manual step.
        String[] items=csv.split("\\|",-1);
        if(items.length!=p.steps.size())throw new IllegalStateException(p.id+" action count "+items.length+" != steps "+p.steps.size());
        for(int i=0;i<items.length;i++)if(!items[i].isEmpty())p.actions.put(i,items[i]);
    }
    private static void defineActions(Plan p){switch(p.id){
        case "W01":set(p,"T34|DIAL|T01|OBSERVE_CALL|T03|T04|T05|OBSERVE_SEND|OBSERVE_PEER|T13|OBSERVE_END|T18");break;
        case "W02":set(p,"T02|OBSERVE_RING|OBSERVE_ANSWER|OBSERVE_CALL|T03|T04|T05|T18");break;
        case "W03":set(p,"T01|T03|OBSERVE_MIC|VOICE_INPUT|VOICE_DISPATCH|OBSERVE_PEER|T08|T11|OBSERVE_MODE|T18");break;
        case "W04":set(p,"OBSERVE_CALL|T17|OBSERVE_TRANSLATE|OBSERVE_REMOTE|T09|T10|T24|OBSERVE_PEER|OBSERVE_LANGUAGE|T18");break;
        case "W05":set(p,"T01|OBSERVE_ARS|T19|T20|OBSERVE_MENU|T16|OBSERVE_BRANCH|T22|T23|T21|T18");break;
        case "W06":set(p,"OBSERVE_CALL|T12|OBSERVE_REMOTE|OBSERVE_BG|OBSERVE_RECOVER|OBSERVE_NETWORK|T33|T18");break;
        case "W07":set(p,"T25|OBSERVE_NUMBER|T02|T26|OBSERVE_WARNING|T27|OBSERVE_GUARDIAN|T18");break;
        case "W08":set(p,"OBSERVE_SOURCE|T29|OBSERVE_SUMMARY|OBSERVE_ACCURACY|OBSERVE_APPROVAL|OBSERVE_CALENDAR|T18");break;
        case "I01":set(p,"T34|OBSERVE_ROLE|T17|OBSERVE_OEM|OBSERVE_SKT|T18");break;
        case "I02":set(p,"T14|OBSERVE_TALKBACK|OBSERVE_CONFLICT|T18");break;
        case "I03":set(p,"T28|OBSERVE_SEARCH|OBSERVE_ORIGIN|T18");break;
        case "I04":set(p,"T30|OBSERVE_SMS|OBSERVE_COMPARE|T18");break;
        case "I05":set(p,"T31|OBSERVE_RECORD|OBSERVE_REPORT|OBSERVE_SUBMIT|T18");break;
        case "I06":set(p,"T32|OBSERVE_ROAMING|OBSERVE_PROVIDER|T18");break;
        default:throw new IllegalStateException("Unknown v4 ID: "+p.id);
    }}
    public static Plan find(String id){return BY_ID.get(id);}
    public static List<Plan> flows(){return Collections.unmodifiableList(FLOWS);}
    public static List<Plan> isolated(){return Collections.unmodifiableList(ISOLATED);}
    public static String version(){return "v5.0 / 8 flows + 6 standalone, W03 voice input";}
}
