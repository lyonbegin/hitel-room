package app.hitel.samsungprobe;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Per-scenario and per-feature real-device test runner. Never replaces default dialer. */
public class ScenarioEngineService extends Service {
    public static final String START="app.hitel.flowlab.RUN",STOP="app.hitel.flowlab.STOP",CONFIRM_TEXT="app.hitel.flowlab.CONFIRM_TEXT",
            TTS_HEARD="app.hitel.flowlab.TTS_HEARD",TTS_NOT_HEARD="app.hitel.flowlab.TTS_NOT_HEARD",
            VOICE_CHOICE="app.hitel.flowlab.VOICE_CHOICE",VOICE_CANCEL="app.hitel.flowlab.VOICE_CANCEL";
    public static volatile String currentTest="",currentScenario="",currentState="대기",currentStep="";
    public static volatile boolean awaitingTextApproval=false;
    public static volatile boolean awaitingVoiceInput=false;
    public static volatile String draftText="";
    private volatile boolean textApproved=false;
    public static volatile boolean active=false;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean stop=new AtomicBoolean(false);
    private boolean hadRinging,seenOffhook;
    private int lastPhoneState=-1;
    private String speechText="";
    private volatile boolean voiceDecisionReceived=false;
    private volatile String chosenVoiceMode="",voiceInputSource="",voiceLanguage="ko-KR",voiceSttError="";
    private static final Set<String> PHONE_TESTS=new HashSet<>(Arrays.asList(
        "T01","T02","T03","T04","T05","T06","T07","T08","T09","T10","T11","T12","T13","T14","T16",
        "T19","T20","T21","T22","T23","T24","T25","T26","T27","T33"));
    private static final String[] APPS={
        "com.samsung.android.incallui","com.samsung.android.dialer","com.samsung.android.callassistant",
        "com.samsung.android.incall.contentprovider","com.samsung.android.app.telephonyui",
        "com.samsung.android.intellivoiceservice","com.skt.prod.dialer","com.skt.nugu.apollo"};
    private static class Decision {
        String status,reason;
        JSONObject evidence;
        Decision(String status,String reason,JSONObject evidence){this.status=status;this.reason=reason;this.evidence=evidence;}
    }
    @Override public void onCreate(){super.onCreate();ScenarioCatalog.load(this);FlowCatalog.load(this);LabStore.init(this);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(STOP.equals(intent.getAction())){stop.set(true);awaitingTextApproval=false;awaitingVoiceInput=false;
            LabStore.log("STOP_REQUEST","사용자가 흐름 검증 종료를 요청했습니다");return START_NOT_STICKY;}
        if(VOICE_CANCEL.equals(intent.getAction())){
            if(active&&"W03".equals(currentScenario)&&awaitingVoiceInput){
                chosenVoiceMode="cancel";voiceDecisionReceived=true;awaitingVoiceInput=false;
                LabStore.log("VOICE_INPUT_CANCEL","사용자가 별도 음성 입력 화면을 취소함");
            }
            return START_NOT_STICKY;
        }
        if(VOICE_CHOICE.equals(intent.getAction())){
            String selection=intent.getStringExtra("mode"),value=intent.getStringExtra("text");
            if(active&&"W03".equals(currentScenario)&&awaitingVoiceInput&&value!=null&&!value.isBlank()&&
                ("oem_tts".equals(selection)||"sms".equals(selection)||"voice".equals(selection))){
                speechText=value.trim();chosenVoiceMode=selection;
                voiceInputSource=intent.getStringExtra("source");voiceLanguage=intent.getStringExtra("language");
                voiceSttError=intent.getStringExtra("stt_error");
                if(voiceInputSource==null)voiceInputSource="MANUAL";
                if(voiceLanguage==null)voiceLanguage="";
                if(voiceSttError==null)voiceSttError="";
                textApproved=true;voiceDecisionReceived=true;awaitingVoiceInput=false;
                LabStore.saveVoiceDecision(speechText,selection,voiceInputSource,voiceLanguage,voiceSttError);
                LabStore.log("VOICE_INPUT_CONFIRMED","사용자가 선택한 전송경로="+selection+" / 입력경로="+voiceInputSource);
            }
            return START_NOT_STICKY;
        }
        if(TTS_HEARD.equals(intent.getAction())||TTS_NOT_HEARD.equals(intent.getAction())){
            if(active&&(currentTest.equals("T05")||currentTest.equals("T07")))
                LabStore.markManual(TTS_HEARD.equals(intent.getAction())?"PASS":"FAIL",
                    TTS_HEARD.equals(intent.getAction())?"시험 상대방의 합성음 청취를 사용자가 확인":"시험 상대방이 합성음을 듣지 못함을 사용자가 확인");
            return START_NOT_STICKY;
        }
        if(CONFIRM_TEXT.equals(intent.getAction())){
            String confirmed=intent.getStringExtra("text");
            if(active&&awaitingTextApproval&&confirmed!=null&&!confirmed.trim().isEmpty()){
                speechText=confirmed.trim();textApproved=true;awaitingTextApproval=false;
                LabStore.log("STT_TEXT_APPROVED","사용자가 STT 문장을 확인 및 수정하여 승인함: "+speechText);
            }
            return START_NOT_STICKY;
        }
        if(active)return START_NOT_STICKY;
        String mode=intent.getStringExtra("mode"),id=intent.getStringExtra("id");
        FlowCatalog.Plan plan=FlowCatalog.find(id);
        if(plan==null||(!"flow".equals(mode)&&!"isolated".equals(mode))||!mode.equals(plan.flow?"flow":"isolated"))return START_NOT_STICKY;
        active=true;stop.set(false);currentState="실행 중";currentTest="";currentScenario=id;currentStep="";
        awaitingTextApproval=false;awaitingVoiceInput=false;draftText="";textApproved=false;speechText="";
        voiceDecisionReceived=false;chosenVoiceMode="";voiceInputSource="";voiceLanguage="ko-KR";voiceSttError="";
        hadRinging=false;seenOffhook=false;lastPhoneState=-1;
        try{startNotification();}catch(Throwable e){active=false;currentState="알림 서비스 오류: "+e;stopSelf();return START_NOT_STICKY;}
        worker.execute(()->executeFlow(mode,id,plan));
        return START_NOT_STICKY;
    }
    private void startNotification(){
        String channel="call_scenario_lab_v1";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(channel,"통화 시나리오 실시간 검증",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_NEW_TASK),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopAction=PendingIntent.getService(this,2,new Intent(this,ScenarioEngineService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent heard=PendingIntent.getService(this,31,new Intent(this,ScenarioEngineService.class).setAction(TTS_HEARD),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent notHeard=PendingIntent.getService(this,32,new Intent(this,ScenarioEngineService.class).setAction(TTS_NOT_HEARD),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent voiceInput=PendingIntent.getActivity(this,41,
            new Intent(this,VoiceInputActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,channel)
            .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("통화 시나리오 검사 및 로그 기록 중")
            .setContentText("시험 종료시 한 흐름의 전체 단계 ZIP을 Downloads에 저장합니다")
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_btn_speak_now,"W03 음성 입력",voiceInput).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_send,"상대방 TTS 청취",heard).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_delete,"TTS 미수신",notHeard).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"종료 및 저장",stopAction).build()).build();
        startForeground(826,n);
    }
    private void executeFlow(String mode,String id,FlowCatalog.Plan plan){
        try{
            LabStore.begin(this,mode,id);
            CallAccessibilityService access=CallAccessibilityService.instance;
            if(access!=null)access.resetEvidence();
            collectSystemEvidence();
            boolean writable=LabStore.checkDownloadsWritable(this);
            LabStore.log("COMMON_PREFLIGHT",writable?"Download MediaStore read/write/delete success":"Download write check failed; exports may fail");
            LabStore.log("FLOW_PLAN",id+" "+plan.title+" / "+plan.steps.size()+" ordered steps / scenarios="+String.join(",",plan.scenarios));
            for(int i=0;i<plan.steps.size()&&!stop.get();i++){
                String step=plan.steps.get(i);
                String action=plan.actions.getOrDefault(i,"OBSERVE");
                currentStep=(i+1)+"/"+plan.steps.size()+" "+step;
                currentState="실행 중 · "+currentStep;
                LabStore.log("FLOW_STEP_START",id+" ["+(i+1)+"/"+plan.steps.size()+"] "+step+" / action="+action);
                if(access!=null)access.scanBlocking("flow_step_"+id+"_"+(i+1));
                String verdict="UNVERIFIED",reason="실제 단말·사용자·상대방의 추가 증거가 필요한 단계";
                try{
                    if(action.startsWith("T")&&action.length()==3){
                        currentTest=action;
                        LabStore.startTest(action);
                        if(access!=null){access.scanBlocking("step_start_"+id+"_"+i);access.captureScreenshot("step_start_"+id+"_"+i);}
                        Decision result=perform(action);
                        if(access!=null)access.scanBlocking("step_end_"+id+"_"+i);
                        LabStore.finishTest(this,result.status,result.reason,result.evidence);
                        verdict=result.status;reason=result.reason;
                        currentTest="";
                    } else if("VOICE_INPUT".equals(action)){
                        Decision d=waitVoiceInput();verdict=d.status;reason=d.reason;
                    } else if("VOICE_DISPATCH".equals(action)){
                        Decision d=dispatchVoiceSelection();verdict=d.status;reason=d.reason;
                    } else if("CONFIRM_STT".equals(action)){
                        Decision d=waitTextApproval();verdict=d.status;reason=d.reason;
                    } else if("DIAL".equals(action)){
                        verdict="UNVERIFIED";reason="기존 전화 앱 호출은 사용자 화면에서 확인. 전화 발신 자체는 수행하지 않음";
                    } else if(action.startsWith("OBSERVE")){
                        Decision d=observeStep(action,step);verdict=d.status;reason=d.reason;
                    }
                }catch(Throwable e){verdict="FAIL";reason="단계 실행 예외: "+e;LabStore.log("STEP_EXCEPTION",reason);}
                LabStore.saveFlowStep(i,plan.steps.size(),step,action,verdict,reason);
            }
            LabStore.finishRun(this,stop.get()?"사용자가 중단. 완료된 단계와 전체 로그를 보존함":"계획된 모든 단계 실행/증거검사 종료");
        }catch(Throwable e){
            LabStore.log("ENGINE_FATAL",e.toString());LabStore.finishRun(this,"실행 엔진 오류: "+e);
        }finally{
            active=false;currentTest="";currentScenario="";currentStep="";
            awaitingTextApproval=false;awaitingVoiceInput=false;
            currentState=stop.get()?"중단 · 결과 저장 완료 또는 오류 확인 필요":"종료 · 결과 저장 완료 또는 오류 확인 필요";
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    /** Pauses W03 at the voice screen while call control remains with the system phone app.
     *  The app can be opened from our ongoing notification, never by forcing a
     *  background activity launch. */
    private Decision waitVoiceInput(){
        currentTest="T06";LabStore.startTest("T06");
        voiceDecisionReceived=false;awaitingVoiceInput=true;
        LabStore.log("VOICE_INPUT_AWAIT","삼성 문자통화에서 W03 음성 입력 화면으로 전환하십시오: 알림의 'W03 음성 입력' 또는 앱 내부 버튼. 별도 Activity에서 마이크 STT 실행.");
        long until=System.currentTimeMillis()+180000;
        while(!stop.get()&&!voiceDecisionReceived&&System.currentTimeMillis()<until)sleep(250);
        awaitingVoiceInput=false;
        Decision verdict;
        if(stop.get()||!voiceDecisionReceived||"cancel".equals(chosenVoiceMode)){
            verdict=d("NOT_TESTED",stop.get()?"사용자 중단":"사용자 입력 취소/시간 초과(3분). 자동 전송 없음", "T06");
        }else if("STT".equals(voiceInputSource)||"STT_EDITED".equals(voiceInputSource)){
            verdict=d("UNVERIFIED","포그라운드 음성 인식 결과 확보 및 사용자가 문장 확정. 실제 발화 정확도는 수동 확인 필요. 선택="+chosenVoiceMode,"T06");
        }else{
            verdict=d("UNVERIFIED","시스템 음성인식 성공은 미확인; 사용자가 문장을 직접 입력하여 후속 전송을 선택함. STT 오류="+voiceSttError,"T06");
        }
        LabStore.finishTest(this,verdict.status,verdict.reason,verdict.evidence);currentTest="";
        return verdict;
    }
    /** Branch-specific delivery; not a second duplicated W03 button. */
    private Decision dispatchVoiceSelection(){
        if(!voiceDecisionReceived||speechText.isBlank()||"cancel".equals(chosenVoiceMode))
            return d("NOT_TESTED","확정된 사용자 문장과 전송 방식이 없어 송신을 시도하지 않음","W03");
        if("oem_tts".equals(chosenVoiceMode)){
            currentTest="T07";LabStore.startTest("T07");
            LabStore.log("VOICE_OEM_TTS","문자통화 입력 화면으로 복귀하고 확인된 문장을 삼성 입력창에 전달하여 OEM TTS 전송을 시도");
            openCallScreen();sleep(1500);
            Decision decision=sendTest("T07");
            LabStore.finishTest(this,decision.status,decision.reason,decision.evidence);currentTest="";
            return decision;
        }
        if("sms".equals(chosenVoiceMode))return d("UNVERIFIED",
            "사용자가 SMS 작성 화면 열기를 선택함. 문장 작성 단계까지만 자동화하며 실제 SMS 송신은 사용자 확인 필요. 통화 회선 TTS가 아님","W03");
        if("voice".equals(chosenVoiceMode)){
            LabStore.log("VOICE_LIVE_MODE","사용자가 명시적으로 일반 음성통화를 선택함. 녹음 파일을 상대방에게 주입하지 않음");
            openCallScreen();sleep(1000);
            CallAccessibilityService a=CallAccessibilityService.instance;
            boolean clicked=a!=null&&a.switchToVoiceCall();
            LabStore.log("VOICE_MODE_SWITCH","삼성 문자통화→일반 음성 전환 버튼 호출="+clicked+" / 실제 통화 모드는 사용자 확인 필요");
            return d("UNVERIFIED",clicked?
                "사용자 선택에 따라 삼성 일반 음성통화 전환 노드 클릭. 실제 통화 모드와 상대방 청취 확인 필요":
                "삼성 일반 음성통화 전환 버튼이 노출되지 않음. 통화 화면에서 사용자가 직접 전환한 후 새로 말해야 함","W03");
        }
        return d("NOT_TESTED","알 수 없는 전송 방식="+chosenVoiceMode,"W03");
    }
    private Decision waitTextApproval(){
        if(speechText==null||speechText.isBlank())return d("NOT_TESTED","인식된 STT 문장이 없어 사용자 확인 단계 불가","W03");
        textApproved=false;draftText=speechText;awaitingTextApproval=true;
        LabStore.log("STT_APPROVAL_REQUIRED","HITEL 앱을 열어 STT 문장을 확인·수정 후 승인하십시오. 승인 전에는 TTS 송출하지 않습니다.");
        // Notification brings user back without acquiring OS-level carrier audio.
        long deadline=System.currentTimeMillis()+90000;
        while(!stop.get()&&awaitingTextApproval&&System.currentTimeMillis()<deadline)sleep(250);
        if(!stop.get()&&awaitingTextApproval){awaitingTextApproval=false;LabStore.log("STT_APPROVAL_TIMEOUT","90초 내 미확인");}
        return d(textApproved?"PASS":"NOT_TESTED",textApproved?"사용자가 STT 텍스트를 확인 및 승인함":"사용자 승인 없이 TTS 전송 단계 건너뜀","W03");
    }
    private Decision observeStep(String action,String step){
        CallAccessibilityService.Snapshot a=snap("flow_"+action);
        if("OBSERVE_CALL".equals(action)){
            int s=state();return d(s==TelephonyManager.CALL_STATE_OFFHOOK?"UNVERIFIED":"NOT_TESTED",
                "휴대전화 통화 상태="+s+" / 현재 화면="+(a==null?"unknown":a.foregroundPackage)+"; OFFHOOK만으로 실제 상대 연결·송신 성공은 판정하지 않음",action);
        }
        if("OBSERVE_REMOTE".equals(action))return d(a!=null&&a.remoteCount>0?"UNVERIFIED":"NOT_TESTED",
            "원격 문자 관찰 횟수="+(a==null?0:a.remoteCount)+"; 실제 상대방 발화 정확도는 별도 검증",action);
        if("OBSERVE_PEER".equals(action)&&"W03".equals(currentScenario)&&!"oem_tts".equals(chosenVoiceMode))
            return d("NOT_TESTED","삼성 TTS를 선택하지 않았으므로 상대방 TTS 청취 검증 대상이 아님; 선택="+chosenVoiceMode,action);
        if("OBSERVE_MODE".equals(action)&&"W03".equals(currentScenario)){
            boolean shown=CallAccessibilityService.instance!=null&&CallAccessibilityService.instance.isTextCallVisible();
            return d("UNVERIFIED","전송방식="+chosenVoiceMode+" / 현재 삼성 문자통화 입력창 보임="+shown+
                " / 이 값은 화면 상태이며 회선에 원음이 전달되는지의 증거는 아님",action);
        }
        if("OBSERVE_SEND".equals(action)||"OBSERVE_PEER".equals(action))return d("UNVERIFIED",
            "상대방 TTS 수신을 이 APK 혼자 입증할 수 없음. 체크포인트 T05/T07의 사용자가 확인한 결과 참고",action);
        if("OBSERVE_RING".equals(action)||"OBSERVE_ANSWER".equals(action))return d(hadRinging?"UNVERIFIED":"NOT_TESTED",
            "실제 RINGING 관측="+hadRinging+" / OFFHOOK 관측="+seenOffhook+". 사용자 직접 수신/응답만 허용",action);
        if("OBSERVE_MIC".equals(action))return d(granted(Manifest.permission.RECORD_AUDIO)?"PASS":"NOT_TESTED",
            "앱 자체 마이크 권한="+granted(Manifest.permission.RECORD_AUDIO)+". 통화 음성 캡처 권한이 아님",action);
        if("OBSERVE_BG".equals(action))return d(a!=null&&a.remoteBackgroundCount>0?"UNVERIFIED":"NOT_TESTED",
            "백그라운드 신규 자막="+(a==null?0:a.remoteBackgroundCount)+"; 발화 시점 대조 필요",action);
        if("OBSERVE_END".equals(action))return d(state()==TelephonyManager.CALL_STATE_IDLE?"PASS":"UNVERIFIED",
            "종료시 실제 통화 상태="+state()+". 기존 통화 강제 종료하지 않음",action);
        if("OBSERVE_RECOVER".equals(action))return d(a!=null&&!a.foregroundPackage.isEmpty()?"UNVERIFIED":"NOT_TESTED",
            "복귀 후 접근성 화면="+(a==null?"none":a.foregroundPackage),action);
        return d("UNVERIFIED","실제 사용자의 조작 또는 외부 데이터 연동이 필요한 단계: "+step+" [미구현을 성공 처리하지 않음]",action);
    }
    private void collectSystemEvidence(){
        for(String pkg:APPS){
            try{PackageInfo pi=getPackageManager().getPackageInfo(pkg,0);
                LabStore.log("PACKAGE_INSTALLED",pkg+" "+pi.versionName);
            }catch(Exception e){LabStore.log("PACKAGE_NOT_VISIBLE",pkg+" - 미설치 또는 패키지 조회 불가");}
        }
        try{
            TelecomManager t=(TelecomManager)getSystemService(TELECOM_SERVICE);
            LabStore.log("DEFAULT_DIALER",t.getDefaultDialerPackage()+" (변경하지 않음)");
        }catch(Exception e){LabStore.log("DIALER_ERROR",e.toString());}
        LabStore.log("ACCESSIBILITY",CallAccessibilityService.instance==null?"권한/서비스 미연결":"삼성 통화 접근성 서비스 활성");
        LabStore.log("PERMISSION","READ_PHONE_STATE="+granted(Manifest.permission.READ_PHONE_STATE)+" RECORD_AUDIO="+granted(Manifest.permission.RECORD_AUDIO));
    }
    private boolean granted(String perm){return checkSelfPermission(perm)==PackageManager.PERMISSION_GRANTED;}
    private int state(){
        try{
            if(!granted(Manifest.permission.READ_PHONE_STATE))return -1;
            TelephonyManager t=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
            int s=t.getCallState();
            if(s!=lastPhoneState){lastPhoneState=s;LabStore.log("CALL_STATE",s==0?"IDLE":s==1?"RINGING":s==2?"OFFHOOK":"UNKNOWN");}
            if(s==TelephonyManager.CALL_STATE_RINGING)hadRinging=true;
            if(s==TelephonyManager.CALL_STATE_OFFHOOK)seenOffhook=true;
            return s;
        }catch(Exception e){LabStore.log("CALL_STATE_ERROR",e.toString());return -1;}
    }
    private void openCallScreen(){
        main.post(()->{
            try{
                TelecomManager telecom=(TelecomManager)getSystemService(TELECOM_SERVICE);
                telecom.showInCallScreen(false);
                LabStore.log("CALL_SCREEN_OPEN","TelecomManager.showInCallScreen(false) 요청");
            }catch(Exception e){LabStore.log("CALL_SCREEN_UNAVAILABLE",e.toString());}
        });
    }
    private boolean waitCall(int ms){
        long until=System.currentTimeMillis()+ms;
        while(!stop.get()&&System.currentTimeMillis()<until){
            int s=state();if(s==TelephonyManager.CALL_STATE_OFFHOOK)return true;
            sleep(800);
        }
        return false;
    }
    private void sleep(int ms){try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();stop.set(true);}}
    private CallAccessibilityService.Snapshot snap(String reason){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return null;
        a.scanBlocking(reason);return a.snapshot();
    }
    private JSONObject baseEvidence(String id){
        JSONObject j=new JSONObject();
        try{
            j.put("testId",id);j.put("timestamp",System.currentTimeMillis()).put("phoneState",state());
            j.put("ringingObserved",hadRinging).put("offhookObserved",seenOffhook);
            CallAccessibilityService.Snapshot a=CallAccessibilityService.instance==null?null:CallAccessibilityService.instance.snapshot();
            if(a!=null){
                j.put("accessibilityForegroundPackage",a.foregroundPackage);
                j.put("accessibilityViewIds",new JSONArray(a.ids));
                j.put("accessibilityWindowPackages",new JSONArray(a.pkgs));
                j.put("remoteTextCount",a.remoteCount).put("localTextCount",a.localCount)
                    .put("translatedTextCount",a.translatedCount).put("newRemoteWhileBackground",a.remoteBackgroundCount)
                    .put("lastRemoteText",a.lastRemote).put("lastLocalText",a.lastLocal)
                    .put("lastTranslatedText",a.lastTranslated);
            }
        }catch(Exception ignored){}
        return j;
    }
    private Decision d(String status,String reason,String test){
        LabStore.log("VERDICT",test+" = "+status+" | "+reason);
        return new Decision(status,reason,baseEvidence(test));
    }
    private Decision waitEvidence(String id,int seconds,java.util.function.Predicate<CallAccessibilityService.Snapshot> condition,String note){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스가 비활성화되어 화면 검증 불가",id);
        for(int i=0;i<seconds&&!stop.get();i++){
            CallAccessibilityService.Snapshot s=snap("trial_"+id);
            if(s!=null&&condition.test(s))return d("PASS",note+" [접근성 노드 관측]",id);
            sleep(1000);
        }
        return d("UNVERIFIED",note+" — 시험 시간 동안 필요 증거 미관측",id);
    }
    private Decision perform(String id){
        LabStore.log("STEP","["+id+"] 실제 관측과 자동검사 시작. 검증 불가능한 결과는 성공 표시하지 않습니다.");
        if(id.equals("T34")){collectSystemEvidence();return d("PASS","실제 설치 패키지, 기본 전화 역할, 접근성 상태 조회 완료 (기능 활성화까지 보증하지 않음)",id);}
        if(id.equals("T18")){
            boolean writable=LabStore.checkDownloadsWritable(this);
            return d(writable?"PASS":"FAIL",writable?
                "Downloads 파일 생성·데이터 읽기·삭제 확인 성공. 개별 시험 ZIP은 별도로 자동 저장":"Downloads 실제 쓰기·재읽기 검사가 실패하였습니다",id);
        }
        if(id.equals("T17")){
            String p=CallAccessibilityService.instance==null?"없음":"연결";
            return d("UNVERIFIED","접근성 서비스="+p+"; 언어팩·OEM 기능의 실제 사용 가능성은 삼성 화면에서 별도 판정",id);
        }
        if(id.equals("T14")||id.equals("T21")){
            String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            boolean talkback=enabled!=null&&(enabled.toLowerCase(Locale.ROOT).contains("talkback"));
            LabStore.log("TALKBACK_STATUS","TalkBack enabled="+talkback+"; enabledServices="+enabled);
            return d(talkback&&CallAccessibilityService.instance!=null?"UNVERIFIED":"NOT_TESTED",talkback?"TalkBack과 진단 접근성 서비스가 동시에 활성화됨. 실제 터치·키보드 성공은 별도 확인 필요":"TalkBack 또는 진단 접근성 서비스가 켜져 있지 않음",id);
        }
        if(id.equals("T15"))return d("UNSUPPORTED","수어 인식·수어→문자 처리 모듈은 이번 진단 APK에 아직 구현되지 않았습니다",id);
        if(id.equals("T25"))return d("UNSUPPORTED","CallScreeningService 역할 및 실제 평판 데이터베이스가 연결되지 않았습니다",id);
        if(id.equals("T27"))return d("UNSUPPORTED","보호자 등록과 실제 전달 가능한 알림 채널이 아직 연결되지 않았습니다",id);
        if(id.equals("T28"))return d("UNSUPPORTED","업체 검색을 위한 검증된 실제 사업체 API가 아직 연결되지 않았습니다",id);
        if(id.equals("T30"))return d("UNSUPPORTED","SMS 읽기 및 사용자 선택 자료 연결 기능은 현재 진단 앱에 구현되지 않았습니다",id);
        if(id.equals("T31"))return d("UNSUPPORTED","신고 접수 API와 녹음 자료 연결이 없어 실제 신고 완료를 검증할 수 없습니다",id);
        if(id.equals("T32"))return checkNetwork(id);
        if(id.equals("T29"))return d("UNVERIFIED","전사 로그는 실제로 확보되는 경우 ZIP에 보존합니다. AI 요약·일정 정확도 검증에는 원문과 실제 엔진이 필요합니다",id);
        if(id.equals("T10")||id.equals("T20"))return d("UNSUPPORTED","검증 가능한 실시간 언어 번역 엔진 및 외부전화 TTS 송출 경로는 이 진단 앱에 아직 연결되지 않았습니다",id);
        if(id.equals("T08")){
            if("W03".equals(currentScenario)&&!"oem_tts".equals(chosenVoiceMode))
                return d("NOT_TESTED","삼성 문자통화 TTS 전송 방식이 아니므로 T08 원음 차단 검사를 실행하지 않음",id);
            return d("UNSUPPORTED","일반 앱은 이동통신 송신 원음을 강제로 차단할 수 없습니다. 삼성 문자통화의 OEM 원음 차단은 상대 기기 확인 전 성공 판정 불가",id);
        }
        if(id.equals("T16"))return d("UNVERIFIED","삼성 통화 중 DTMF 입력 화면을 이용할 수 있으나 외부 ARS 분기 결과는 상대방 콜센터 증거가 필요합니다. 임의 숫자는 전송하지 않았습니다",id);
        if(id.equals("T22")||id.equals("T23")){
            boolean ongoing=waitCall(15000);
            return d(ongoing?"UNVERIFIED":"NOT_TESTED",ongoing?"일반전화 통화 상태는 관측됨. 상담원 대기·실제 연결은 확인 가능한 음성·전사 근거가 추가로 필요":"대기 시험을 위한 실제 연결 통화가 없음",id);
        }
        if(id.equals("T01")){
            boolean call=waitCall(23000);
            return d(call?"UNVERIFIED":"NOT_TESTED",call?"OFFHOOK 관측, 하지만 발신 방향과 상대방 응답은 OFFHOOK만으로 확정할 수 없음":"실제 발신 연결이 관측되지 않음",id);
        }
        if(id.equals("T02")){
            boolean call=waitCall(32000);
            if(call&&hadRinging)return d("PASS","이 테스트 동안 RINGING → OFFHOOK 이력이 실제 관측됨 (상대방 음성 확인은 별도)",id);
            return d(call?"UNVERIFIED":"NOT_TESTED",call?"OFFHOOK만 확인. 수신벨 및 사용자 수락 이벤트 미확보":"기기에서 수신 통화가 확인되지 않음",id);
        }
        if(id.equals("T03")){
            if(!waitCall(17000))return d("NOT_TESTED","실제 통화 상태 없음. 전화 앱/테스트 상대방 연결 필요",id);
            openCallScreen();sleep(1200);
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            a.scanBlocking("textcall_before");
            if(a.snapshot().textCall)return d("PASS","텍스트 통화 입력창 실제 확인",id);
            a.enterTextCall();return waitEvidence(id,9,s->s.textCall,"삼성 문자통화 입력창·메시지 목록 노출");
        }
        if(id.equals("T04")){
            if(!waitCall(12000))return d("NOT_TESTED","원격 발화를 확인할 통화가 없음",id);
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            int before=a.snapshot().remoteCount;openCallScreen();
            for(int i=0;i<14&&!stop.get();i++){
                a.scanBlocking("caption_trial");
                if(a.snapshot().remoteCount>before)return d("UNVERIFIED","새 remote_message 자막 노드 관찰. 실제 음성의 내용·정확도는 상대방과 대조 필요",id);
                sleep(1000);
            }
            return d("UNVERIFIED","새 원격 발화 자막 미관측. 실제 전화 상대방 발화 및 OEM 자막 활성화 확인 필요",id);
        }
        if(id.equals("T05")||id.equals("T07"))return sendTest(id);
        if(id.equals("T06"))return runStt(id);
        if(id.equals("T09")){
            if(!waitCall(12000))return d("NOT_TESTED","번역 확인에 필요한 실제 통화 없음",id);
            return waitEvidence(id,11,s->s.translatedCount>0,"OEM 번역문 노드 존재. 번역 정확도는 원어와 수동 대조가 추가로 필요");
        }
        if(id.equals("T11")){
            if("W03".equals(currentScenario)&&"sms".equals(chosenVoiceMode))
                return d("NOT_TESTED","SMS 작성 경로는 삼성 음성/문자 통화 모드 전환 검사가 아님",id);
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            boolean was=a.snapshot().textCall;
            return d(was?"UNVERIFIED":"NOT_TESTED",was?"문자통화 화면 관측. STT 진입 이후의 모드 유지 여부는 T06/T07 로그와 비교 필요":"진입한 문자통화 화면이 없어서 모드 유지 확인 불가",id);
        }
        if(id.equals("T12"))return backgroundTrial(id);
        if(id.equals("T13")){
            CallAccessibilityService.Snapshot s=snap("reciprocal");
            return d(s!=null&&s.remoteCount>=5&&s.localCount>=5?"UNVERIFIED":"NOT_TESTED",
                s!=null?"원격 자막="+s.remoteCount+" 발신 문자="+s.localCount+"; 각 회차의 실제 상대방 청취까지 확인해야 최종 합격":"왕복 메시지 증거 없음",id);
        }
        if(id.equals("T19"))return arsTrial(id);
        if(id.equals("T24"))return d("UNVERIFIED","실제 외국어 TTS 상대방 수신은 다른 단말 확인 필요. 현재 진단 APK가 통화 오디오를 직접 주입하지 않습니다",id);
        if(id.equals("T26"))return phishingTrial(id);
        if(id.equals("T33"))return checkNetwork(id);
        return d("UNVERIFIED","자동 검증 어댑터에서 해당 실제 기능 근거를 확보하지 못했습니다",id);
    }
    private Decision sendTest(String id){
        if(!waitCall(18000))return d("NOT_TESTED","실제 통화 연결 상태가 없어 자동 문자 송출하지 않았습니다",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        if(id.equals("T07")&&!textApproved)return d("NOT_TESTED","사용자의 STT 문장 확인/승인 전에는 자동 송출하지 않습니다",id);
        String text=id.equals("T07")?speechText:"HITEL "+id+" 기능시험 문장입니다.";
        if(text==null||text.isBlank())return d("NOT_TESTED","인식된 STT 문장이 없습니다. T06 음성인식 시험을 먼저 실행해야 합니다",id);
        a.scanBlocking("pre_send");
        if(!a.snapshot().textCall){a.enterTextCall();sleep(1300);a.scanBlocking("post_entry");}
        if(!a.snapshot().textCall)return d("NOT_TESTED","삼성 문자통화 입력창을 열지 못했습니다",id);
        int before=a.snapshot().localCount;
        boolean attempted=a.putAndSend(text);
        if(!attempted)return d("FAIL","삼성 문자 입력/전송 접근성 액션이 성공하지 못했습니다",id);
        long end=System.currentTimeMillis()+16000;boolean messageObserved=false;
        while(!stop.get()&&System.currentTimeMillis()<end){
            a.scanBlocking("send_verify");CallAccessibilityService.Snapshot s=a.snapshot();
            messageObserved|=s.localCount>before&&text.equals(s.lastLocal);
            if("PASS".equals(LabStore.manualStatus())||"FAIL".equals(LabStore.manualStatus()))break;
            sleep(900);
        }
        String human=LabStore.manualStatus();
        if("PASS".equals(human)&&messageObserved)return d("PASS","발신 local_message 노드와 상대방 청취의 사용자 현장 확인 모두 확보",id);
        if("FAIL".equals(human))return d("FAIL","사용자 현장 확인에서 상대방 TTS 미수신 보고",id);
        return d("UNVERIFIED","접근성 버튼 실행="+attempted+", 발신 목록 신규 메시지="+messageObserved+
            ". 상대방 실제 TTS 청취는 미확인(버튼 클릭 성공만으로 PASS 금지)",id);
    }
    private Decision runStt(String id){
        if(!granted(Manifest.permission.RECORD_AUDIO))return d("NOT_TESTED","마이크 권한 미허용. 앱 권한 설정 후 다시 시험",id);
        if(!SpeechRecognizer.isRecognitionAvailable(this))return d("UNSUPPORTED","휴대전화에 시스템 음성인식 서비스가 없음",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        boolean before=a!=null&&a.snapshot().textCall;
        speechText=recognize(14000);
        boolean after=a!=null&&a.snapshot().textCall;
        LabStore.log("STT_RESULT","recognized="+speechText+" textcall_before="+before+" textcall_after="+after);
        if(speechText.isEmpty())return d("UNVERIFIED","마이크 음성인식 결과 없음. 통화 중 마이크 배타 제어 여부와 OEM 정책 추가 확인 필요",id);
        return d("UNVERIFIED","음성인식 문장 수집 성공: '"+speechText+"'. 정확도 사용자 확인과 문자통화 유지 여부는 별도 검증",id);
    }
    private String recognize(int timeoutMs){
        final String[] value={""};CountDownLatch latch=new CountDownLatch(1);
        final SpeechRecognizer[] holder={null};
        main.post(()->{
            try{
                SpeechRecognizer r=SpeechRecognizer.createSpeechRecognizer(this);holder[0]=r;
                r.setRecognitionListener(new RecognitionListener(){
                    @Override public void onReadyForSpeech(Bundle params){LabStore.log("STT","음성 입력 준비됨");}
                    @Override public void onBeginningOfSpeech(){LabStore.log("STT","발화 감지");}
                    @Override public void onRmsChanged(float rms){}
                    @Override public void onBufferReceived(byte[] buffer){}
                    @Override public void onEndOfSpeech(){LabStore.log("STT","발화 종료");}
                    @Override public void onError(int error){LabStore.log("STT_ERROR","error="+error);latch.countDown();}
                    @Override public void onResults(Bundle results){
                        ArrayList<String> choices=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if(choices!=null&&!choices.isEmpty())value[0]=choices.get(0);
                        LabStore.log("STT_TEXT",value[0]);latch.countDown();
                    }
                    @Override public void onPartialResults(Bundle results){
                        ArrayList<String> texts=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if(texts!=null&&!texts.isEmpty())LabStore.log("STT_PARTIAL",texts.get(0));
                    }
                    @Override public void onEvent(int type,Bundle params){}
                });
                Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.KOREAN.toLanguageTag());
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
                r.startListening(intent);
            }catch(Throwable e){LabStore.log("STT_ERROR",e.toString());latch.countDown();}
        });
        try{latch.await(timeoutMs,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        main.post(()->{if(holder[0]!=null){holder[0].cancel();holder[0].destroy();}});
        return value[0];
    }
    private Decision backgroundTrial(String id){
        if(!waitCall(16000))return d("NOT_TESTED","전화 연결이 없는 상태에서 백그라운드 자막 시험 불가",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        a.scanBlocking("before_background");int before=a.snapshot().remoteBackgroundCount;
        a.setBackgroundTrial(true);boolean home=a.home();
        LabStore.log("BACKGROUND_TRIAL","GLOBAL_ACTION_HOME="+home+"; 다른 화면으로 나간 상태에서 실제 새로운 상대방 발화 필요");
        for(int i=0;i<12&&!stop.get();i++)sleep(1000);
        a.setBackgroundTrial(false);openCallScreen();sleep(1200);a.scanBlocking("after_background");
        int count=a.snapshot().remoteBackgroundCount-before;
        return d(count>0?"PASS":"UNVERIFIED",count>0?"백그라운드 상태에서 새로운 자막 "+count+"개 수집. 실제 발화 시점 대조 필요":"백그라운드 새 자막 미관측 (복귀 후 과거 자막은 제외)",id);
    }
    private Decision arsTrial(String id){
        if(!waitCall(14000))return d("NOT_TESTED","실제 ARS 전화가 없는 상태",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        int before=a.snapshot().remoteCount;
        for(int i=0;i<14&&!stop.get();i++){
            a.scanBlocking("ars_caption");
            CallAccessibilityService.Snapshot s=a.snapshot();
            if(s.remoteCount>before){
                String value=s.lastRemote;
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9])\\s*번").matcher(value);
                List<String> menus=new ArrayList<>();while(m.find())menus.add(m.group(1)+"번");
                LabStore.log("ARS_MENU_CANDIDATE","음성자막: "+value+" / 후보 메뉴: "+menus+" (실제 ARS 번호 자동 선택 없음)");
                return d("UNVERIFIED","신규 ARS 자막 확인, 숫자 메뉴 후보="+menus+"; 사용자의 선택과 실제 DTMF 분기 미확인",id);
            }
            sleep(900);
        }
        return d("UNVERIFIED","실제 ARS 자막을 확인하지 못했습니다. SKT 에이전트콜 원본 동작 지원 여부와 별도",id);
    }
    private Decision phishingTrial(String id){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        int before=a.snapshot().remoteCount;
        for(int i=0;i<13&&!stop.get();i++){
            a.scanBlocking("risk_text");CallAccessibilityService.Snapshot s=a.snapshot();
            String text=s.lastRemote;
            if(s.remoteCount>before&&(text.contains("계좌이체")||text.contains("원격 앱")||text.contains("송금")||text.contains("인증번호"))){
                LabStore.log("FRAUD_TEXT_WARNING","실제 OEM 자막의 위험 문자열 감지: "+text+" [텍스트 단서이며 음성 기반 AI 탐지 아님]");
                return d("PASS","실제 자막에서 위험 문자열을 감지하여 경고 이벤트 생성 (피싱 확정 아님)",id);
            }
            sleep(1000);
        }
        return d("UNVERIFIED","시험 중 새로운 위험 문자열이 확인되지 않음. 보이스피싱 음성 탐지로 오인하지 않음",id);
    }
    private Decision checkNetwork(String id){
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            NetworkCapabilities cap=cm.getNetworkCapabilities(cm.getActiveNetwork());
            String connection=cap==null?"NONE":cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"WIFI":
                cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"CELLULAR":"OTHER";
            String roaming="UNKNOWN";
            if(granted(Manifest.permission.READ_PHONE_STATE)){
                TelephonyManager t=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
                roaming=String.valueOf(t.isNetworkRoaming());
            }
            LabStore.log("NETWORK","transport="+connection+" roaming="+roaming);
            return d("PASS","실제 네트워크 전송수단="+connection+", 로밍 여부="+roaming+" 조회 (통신사 baro/Home-Fi Call 구현 성공 아님)",id);
        }catch(Exception e){return d("UNVERIFIED","실제 네트워크 상태 조회 실패: "+e,id);}
    }
    @Override public void onDestroy(){stop.set(true);worker.shutdownNow();active=false;awaitingTextApproval=false;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
