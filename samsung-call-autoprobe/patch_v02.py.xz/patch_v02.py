from pathlib import Path
p=Path(__file__).resolve().parent
acc=p/'app/src/main/java/app/hitel/samsungprobe/CallAccessibilityService.java'
s=acc.read_text()
s=s.replace('    private int events;', '''    private int events;
    private static final String TEST_TEXT="HITEL 자동검증 테스트 문장입니다.";
    private long textEnteredAt=0;
    private long setTextAt=0;
    private long sendAt=0;
    private boolean sendVerified=false;
    private boolean sendInputStillPresentLogged=false;
    private boolean foregroundProbe=false;
    private boolean translationRequested=false;
    public long getTextEnteredAt() { return textEnteredAt; }

    public boolean startBackgroundProbe() {
        if (foregroundProbe || textEnteredAt==0) return false;
        foregroundProbe=true;
        Recorder.event("BACKGROUND_TRIAL","start","기본 전화 앱을 변경하지 않고 홈 화면으로 전환하여 새 자막 이벤트 검증");
        boolean ok=performGlobalAction(GLOBAL_ACTION_HOME);
        Recorder.event("BACKGROUND_TRIAL","home_result","performGlobalAction(GLOBAL_ACTION_HOME)="+ok);
        return ok;
    }
    public void endBackgroundProbe() {
        foregroundProbe=false;
        Recorder.event("BACKGROUND_TRIAL","end","통화 UI 복귀 요청 후 백그라운드에서 실제 신규 remote_message가 있었는지 판정");
    }
    public void requestTranslationProbe() {
        translationRequested=true;
        Recorder.event("TRANSLATION_TRIAL","start","문자통화에서 음성통화로 복귀 후 OEM 통역 버튼 탐색");
        scan("translation_stage");
    }''')
needle='''            if (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && pkg.contains("incall")) {
                String str = event.getText().toString();
                if (!str.isEmpty()) captureMessage("text_change_event", str);
            }'''
replacement='''            if (pkg.equals("com.samsung.android.incallui") && event.getSource()!=null) {
                // Check the actual event source even if InCallUI is no longer an interactive foreground window.
                // This does not assume hidden-window access is always possible on Android.
                AccessibilityNodeInfo node=event.getSource();
                boolean background=foregroundProbe && !isInCallForeground();
                inspectEventSource(node, 0, new int[]{0}, background);
            }'''
assert needle in s
s=s.replace(needle,replacement)
s=s.replace('''    private int signatureCounter;''','''    private boolean isInCallForeground() {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        return root!=null && "com.samsung.android.incallui".equals(s(root.getPackageName()));
    }
    private void inspectEventSource(AccessibilityNodeInfo node,int depth,int[] count, boolean background) {
        if(node==null || depth>12 || count[0]++>300) return;
        String id=s(node.getViewIdResourceName());
        String text=s(node.getText());
        if(!text.isEmpty() && (id.equals(P+"remote_message") || id.equals(P+"remote_message_translated") ||
            id.equals(P+"local_message") || id.equals(P+"local_message_translated"))) {
            captureMessage(id,text,background);
        }
        for(int i=0;i<node.getChildCount();i++) inspectEventSource(node.getChild(i),depth+1,count,background);
    }

    private int signatureCounter;''')
s=s.replace('''            if (!text.isEmpty()) captureMessage(id, text);''','''            if (!text.isEmpty()) captureMessage(id, text, false);''')
needle='''    private void captureMessage(String source, String text) {
        if (text.isEmpty()) return;
        String key=source+":"+text;
        if (seenMessages.size() > 1500) seenMessages.clear();
        if (seenMessages.add(key)) {
            Recorder.event("CAPTION", source, text);
            Recorder.check("caption_nodes", "OBSERVED", "실제 접근성 메시지 노드에서 텍스트를 수집함: " + source);
            if (source.contains("translated")) Recorder.check("translation_nodes", "OBSERVED", "번역문 텍스트를 실제로 수집함");
        }
    }'''
replacement='''    private void captureMessage(String source, String text, boolean background) {
        if (text.isEmpty()) return;
        String key=source+":"+text;
        if (seenMessages.size() > 1500) seenMessages.clear();
        if (seenMessages.add(key)) {
            boolean remote=source.endsWith("/remote_message") || source.endsWith("/remote_message_translated");
            boolean local=source.endsWith("/local_message") || source.endsWith("/local_message_translated");
            Recorder.event(remote ? "REMOTE_CAPTION" : "LOCAL_MESSAGE", source, text);
            if (remote) {
                Recorder.check("caption_nodes", "PASS", "상대방 remote_message 문자 실제 수집: " + source);
                if(background) {
                    Recorder.check("background_caption", "PASS", "통화 화면이 비활성인 상태에서 새로운 원격 자막 이벤트 수집");
                    Recorder.event("BACKGROUND_CAPTION",source,text);
                }
            }
            if (source.contains("translated")) Recorder.check("translation_nodes", "PASS", "실제 번역문 텍스트를 수집함");
            if(local && text.equals(TEST_TEXT)) {
                sendVerified=true;
                Recorder.check("text_call_send", "PASS", "발신 메시지 목록에 테스트 문장 실제 표시 확인; 상대방 TTS 수신은 별도 검증 필요");
            }
        }
    }'''
assert needle in s
s=s.replace(needle,replacement)
s=s.replace('''            Recorder.check("text_call_entry", "PASS", "문자 통화 목록 실제 표시됨");''','''            Recorder.check("text_call_entry", "PASS", "문자 통화 목록 실제 표시됨");
            if(textEnteredAt==0) textEnteredAt=System.currentTimeMillis();''')
needle='''        if (input != null) {
            Recorder.check("text_call_input", "OBSERVED", "텍스트 입력 노드 실제 표시됨, editable=" + input.isEditable());
            if (ProbeService.callActive && attemptedActions.add("set_text")) {
                boolean ok=setText(input,"HITEL 자동검증 테스트 문장입니다.");
                Recorder.check("text_call_input", ok?"PASS":"FAIL", "ACTION_SET_TEXT 반환값=" + ok);
            }
            AccessibilityNodeInfo send = find(root,P+"text_call_submit_button");
            if (send != null && ProbeService.callActive && attemptedActions.contains("set_text") && attemptedActions.add("send_text")) {
                boolean result=click(send);
                Recorder.check("text_call_send", result?"PASS":"FAIL", "연결된 통화에서 문자 테스트 문장 전송 버튼 ACTION_CLICK 반환값=" + result + "; 상대방 수신은 별도 확인 필요");
            }
        }'''
replacement='''        if (input != null) {
            if (!attemptedActions.contains("set_text"))
                Recorder.check("text_call_input", "OBSERVED", "입력창 실제 표시됨, editable=" + input.isEditable());
            if (ProbeService.callActive && attemptedActions.add("set_text")) {
                boolean ok=setText(input,TEST_TEXT);
                setTextAt=System.currentTimeMillis();
                Recorder.check("text_call_input", ok?"PASS":"FAIL", "ACTION_SET_TEXT 반환값=" + ok);
            }
            AccessibilityNodeInfo send = find(root,P+"text_call_submit_button");
            // Wait for a fresh UI snapshot that actually contains the desired text. No instantaneous blind click.
            if(send!=null && ProbeService.callActive && setTextAt>0 && !attemptedActions.contains("send_text") &&
               System.currentTimeMillis()-setTextAt>=700 && TEST_TEXT.equals(s(input.getText()))) {
                attemptedActions.add("send_text");
                boolean ok=click(send);
                sendAt=System.currentTimeMillis();
                Recorder.event("SEND_ATTEMPT","text_call_submit_button","ACTION_CLICK="+ok);
                Recorder.check("text_call_send",ok?"OBSERVED":"FAIL",
                    "버튼 ACTION_CLICK="+ok+"; 발신 메시지 목록과 상대방 수신을 아직 확인하지 못함");
            }
            if(sendAt>0 && !sendVerified && !sendInputStillPresentLogged && System.currentTimeMillis()-sendAt>3500) {
                sendInputStillPresentLogged=true;
                Recorder.event("SEND_VERIFICATION","input_after_click", "text_persisted="+TEST_TEXT.equals(s(input.getText())));
                Recorder.check("text_call_send","OBSERVED","전송 버튼 클릭은 시도했으나 발신 메시지 노드로 확인되지 않음. 입력 잔류="+TEST_TEXT.equals(s(input.getText())));
            }
        }
        if (translationRequested && trans==null && list!=null && attemptedActions.add("return_to_voice")) {
            AccessibilityNodeInfo switcher=find(root,P+"switch_to_voice_call_container");
            if(switcher==null) switcher=find(root,P+"upgrade_to_bixby_text_call_button");
            boolean ok=click(switcher);
            Recorder.event("TRANSLATION_TRIAL","voice_switch","click="+ok);
            return;
        }
        if (translationRequested && trans==null && list==null) {
            String[] candidates={"live_translate_button","ai_call_assist_button"};
            for(String id:candidates) {
                AccessibilityNodeInfo target=find(root,P+id);
                if(target!=null && attemptedActions.add("translation_click:"+id)) {
                    boolean ok=click(target);
                    Recorder.event("TRANSLATION_TRIAL",id,"ACTION_CLICK="+ok);
                    Recorder.check("translation_entry",ok?"OBSERVED":"FAIL","통역 관련 버튼 실행; 통역 화면 진입은 별도 확인");
                    return;
                }
            }
        }'''
assert needle in s
s=s.replace(needle,replacement)
s=s.replace('''        if (trans==null && list==null) {
            // Attempt''','''        if (trans==null && list==null && !translationRequested) {
            // Attempt''')
s=s.replace('''            instance.attemptedActions.clear();
            instance.events=0;''','''            instance.attemptedActions.clear();
            instance.textEnteredAt=0;
            instance.setTextAt=0;
            instance.sendAt=0;
            instance.sendVerified=false;
            instance.sendInputStillPresentLogged=false;
            instance.foregroundProbe=false;
            instance.translationRequested=false;
            instance.events=0;''')
acc.write_text(s)
service=p/'app/src/main/java/app/hitel/samsungprobe/ProbeService.java'
s=service.read_text()
s=s.replace('''    private boolean callScreenRequested;''','''    private boolean callScreenRequested;
    private long backgroundTrialAt;
    private long backgroundRestoredAt;
    private boolean translationTrialIssued;''')
needle='''                        if (CallAccessibilityService.instance!=null && System.currentTimeMillis()>nextScan) {
                            nextScan=System.currentTimeMillis()+2200;
                            CallAccessibilityService.instance.scan("call_active_poll");
                        }'''
replacement='''                        CallAccessibilityService probe=CallAccessibilityService.instance;
                        long now=System.currentTimeMillis();
                        if(probe!=null && now>nextScan) {
                            nextScan=now+2200;
                            probe.scan("call_active_poll");
                        }
                        if (probe!=null && probe.getTextEnteredAt()>0 && backgroundTrialAt==0 &&
                            now-probe.getTextEnteredAt()>18000) {
                            if(probe.startBackgroundProbe()) backgroundTrialAt=now;
                        }
                        if(backgroundTrialAt>0 && backgroundRestoredAt==0 && now-backgroundTrialAt>12000) {
                            backgroundRestoredAt=now;
                            try {
                                TelecomManager telecom=(TelecomManager)getSystemService(TELECOM_SERVICE);
                                telecom.showInCallScreen(false);
                                Recorder.event("BACKGROUND_TRIAL","return_to_call","InCallUI 복귀 호출");
                                if(probe!=null) probe.endBackgroundProbe();
                            } catch(Throwable t) { Recorder.event("ERROR","background_return",t.toString()); }
                        }
                        if(backgroundRestoredAt>0 && !translationTrialIssued && now-backgroundRestoredAt>7500) {
                            translationTrialIssued=true;
                            if(probe!=null) probe.requestTranslationProbe();
                        }'''
assert needle in s
s=s.replace(needle,replacement)
s=s.replace('''Recorder.check("call_detected","PASS","TelephonyManager.CALL_STATE_OFFHOOK 감지");''','''Recorder.check("call_detected","PASS","OFFHOOK 관찰(발신 중도 포함); 실제 상대방 응답은 원격 자막 또는 통화 시간으로 별도 판단");''')
service.write_text(s)
rec=p/'app/src/main/java/app/hitel/samsungprobe/Recorder.java'
s=rec.read_text()
s=s.replace('''"screenshot", "background_events"''','''"screenshot", "background_events", "background_caption", "call_audio_remote_delivery"''')
s=s.replace('Samsung Call AutoProbe v0.1','Samsung Call AutoProbe v0.2')
s=s.replace('''"PASS = 실제 확인, FAIL = 검사 오류, NOT_TESTED = 해당 화면/통화 조건 미발생, OBSERVED = 노드 존재 확인.\\n"''','''"PASS = 실제 관측, FAIL = 오류, NOT_TESTED = 미실시, OBSERVED = 부분관측/결과 불확정.\\n"''')
rec.write_text(s)
main=p/'app/src/main/java/app/hitel/samsungprobe/MainActivity.java'
s=main.read_text().replace('''enabled.toLowerCase().contains("app.hitel.samsungprobe") && enabled.contains("CallAccessibilityService")''','''enabled.toLowerCase().contains(getPackageName().toLowerCase()+"/") && enabled.contains("CallAccessibilityService")''')
main.write_text(s)
build=p/'app/build.gradle.kts'
s=build.read_text().replace('applicationId = "app.hitel.samsungprobe"','applicationId = "app.hitel.samsungprobe.v2"').replace('versionCode = 1','versionCode = 2').replace('versionName = "0.1.0-test"','versionName = "0.2.0-test"')
build.write_text(s)
manifest=p/'app/src/main/AndroidManifest.xml'
s=manifest.read_text().replace('android:label="Samsung 통화 자동검증"','android:label="Samsung 통화 자동검증 v0.2"').replace('android:label="삼성 통화 자동검증 - 화면 분석"','android:label="삼성 통화 자동검증 v0.2 - 화면 분석"')
manifest.write_text(s)
print('patched',acc.stat().st_size,service.stat().st_size)
