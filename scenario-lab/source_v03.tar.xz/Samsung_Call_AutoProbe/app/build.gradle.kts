plugins { id("com.android.application") }
android {
    namespace = "app.hitel.samsungprobe"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.hitel.callscenariolab.v3"
        minSdk = 33
        targetSdk = 33
        versionCode = 3
        versionName = "0.3.0-scenario-lab"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
