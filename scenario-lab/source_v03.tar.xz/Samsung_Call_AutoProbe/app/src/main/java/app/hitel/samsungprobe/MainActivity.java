package app.hitel.samsungprobe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.TypedValue;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** 41 real-world scenario buttons, 34 independent test buttons, unrestricted live log history. */
public class MainActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ArrayList<String> fullLines=new ArrayList<>();
    private ArrayAdapter<String> logAdapter;
    private ListView logList;
    private TextView status,logTitle,tabLabel;
    private ScrollView catalogScroll;
    private LinearLayout catalog;
    private Button followButton;
    private String visibleTab="scenario",pendingMode="",pendingId="";
    private boolean following=true,launchAfterStart=false,requesting=false;
    private long byteOffset;
    private final Runnable monitor=new Runnable(){
        @Override public void run(){
            refreshLogs();
            if(status!=null){
                String label=ScenarioEngineService.active?"검사 중: "+ScenarioEngineService.currentScenario+" / "+ScenarioEngineService.currentTest:
                    "검사 대기 · 마지막 결과: "+getSharedPreferences("lab",MODE_PRIVATE).getString("last_export","없음");
                status.setText(label+"\n실행상태: "+ScenarioEngineService.currentState+" · 매 기능 종료 시 Download에 독립 저장");
            }
            handler.postDelayed(this,450);
        }
    };
    @Override public void onCreate(Bundle b){
        super.onCreate(b);ScenarioCatalog.load(this);LabStore.init(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10),dp(8),dp(10),dp(8));root.setBackgroundColor(Color.WHITE);
        TextView title=text("HITEL 통화 시나리오 자동검증",20,Color.BLACK,true);
        root.addView(title);
        status=text("상태 확인 중",12,Color.DKGRAY,false);status.setPadding(0,dp(5),0,dp(6));root.addView(status);
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.addView(button("시나리오 41",()->showTab("scenario")),new LinearLayout.LayoutParams(0,dp(47),1));
        tabs.addView(button("기능시험 34",()->showTab("test")),new LinearLayout.LayoutParams(0,dp(47),1));
        tabs.addView(button("전체 로그",()->showTab("logs")),new LinearLayout.LayoutParams(0,dp(47),1));
        root.addView(tabs);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("접근성 설정",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),new LinearLayout.LayoutParams(0,dp(44),1));
        actions.addView(button("전화 앱 열기",this::openDialer),new LinearLayout.LayoutParams(0,dp(44),1));
        actions.addView(button("검사 종료",this::stopTest),new LinearLayout.LayoutParams(0,dp(44),1));
        root.addView(actions);
        tabLabel=text("이용 시나리오 — 각 버튼으로 순차 시험",14,Color.BLACK,true);
        tabLabel.setPadding(0,dp(7),0,dp(4));root.addView(tabLabel);
        catalogScroll=new ScrollView(this);catalogScroll.setFillViewport(false);
        catalog=new LinearLayout(this);catalog.setOrientation(LinearLayout.VERTICAL);catalogScroll.addView(catalog);
        root.addView(catalogScroll,new LinearLayout.LayoutParams(-1,0,43));
        LinearLayout logHead=new LinearLayout(this);logHead.setOrientation(LinearLayout.HORIZONTAL);
        logTitle=text("실시간 전체 로그 · 0줄",14,Color.BLACK,true);
        logHead.addView(logTitle,new LinearLayout.LayoutParams(0,dp(42),1));
        followButton=button("자동 스크롤 ON",()->{
            following=!following;followButton.setText(following?"자동 스크롤 ON":"자동 스크롤 OFF");
            if(following&&logAdapter.getCount()>0)logList.setSelection(logAdapter.getCount()-1);
        });
        logHead.addView(followButton,new LinearLayout.LayoutParams(dp(126),dp(42)));
        root.addView(logHead);
        logList=new ListView(this);logList.setDividerHeight(dp(1));logList.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
        logAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,fullLines){
            @Override public View getView(int position,View old,android.view.ViewGroup parent){
                TextView v=old instanceof TextView?(TextView)old:new TextView(MainActivity.this);
                v.setText(getItem(position));v.setTextSize(TypedValue.COMPLEX_UNIT_SP,12);
                v.setTextColor(Color.rgb(22,25,30));v.setPadding(dp(7),dp(6),dp(7),dp(6));
                v.setSingleLine(false);v.setMaxLines(Integer.MAX_VALUE);
                v.setBackgroundColor(position%2==0?0xfff7f7f7:Color.WHITE);return v;
            }
        };
        logList.setAdapter(logAdapter);
        logList.setOnScrollListener(new AbsListView.OnScrollListener(){
            @Override public void onScrollStateChanged(AbsListView v,int state){
                if(state==SCROLL_STATE_TOUCH_SCROLL&&logList.getLastVisiblePosition()<logAdapter.getCount()-2){
                    following=false;followButton.setText("자동 스크롤 OFF");
                }
            }
            @Override public void onScroll(AbsListView v,int first,int visible,int total){}
        });
        root.addView(logList,new LinearLayout.LayoutParams(-1,0,57));
        LinearLayout manual=new LinearLayout(this);manual.setOrientation(LinearLayout.HORIZONTAL);
        manual.addView(button("상대방 확인: 청취 성공",()->manual("PASS","상대방이 실제 합성음을 들었다고 확인하였습니다")),new LinearLayout.LayoutParams(0,dp(45),1));
        manual.addView(button("상대방 확인: 실패",()->manual("FAIL","상대방이 합성음을 받지 못했다고 확인하였습니다")),new LinearLayout.LayoutParams(0,dp(45),1));
        root.addView(manual);
        LinearLayout export=new LinearLayout(this);export.setOrientation(LinearLayout.HORIZONTAL);
        export.addView(button("전체 누적 로그 ZIP 저장",()->new Thread(()->{
            String x=LabStore.exportHistory(this);runOnUiThread(()->toast("저장: "+x));
        }).start()),new LinearLayout.LayoutParams(0,dp(45),1));
        export.addView(button("맨 아래로",()->{following=true;followButton.setText("자동 스크롤 ON");if(logAdapter.getCount()>0)logList.setSelection(logAdapter.getCount()-1);}),new LinearLayout.LayoutParams(0,dp(45),1));
        root.addView(export);
        setContentView(root);showTab("scenario");
        handler.post(monitor);
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int sp,int color,boolean bold){
        TextView x=new TextView(this);x.setText(s);x.setTextSize(sp);x.setTextColor(color);
        if(bold)x.setTypeface(null,android.graphics.Typeface.BOLD);
        x.setGravity(android.view.Gravity.CENTER_VERTICAL);return x;
    }
    private Button button(String title,Runnable cb){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTextSize(12);b.setOnClickListener(v->cb.run());return b;}
    private void toast(String m){Toast.makeText(this,m,Toast.LENGTH_LONG).show();}
    private void showTab(String tab){
        visibleTab=tab;catalog.removeAllViews();
        if("logs".equals(tab)){
            tabLabel.setText("전체 실행 기록 (일부 행 생략 없음)");catalogScroll.setVisibility(View.GONE);
            return;
        }
        catalogScroll.setVisibility(View.VISIBLE);
        tabLabel.setText("scenario".equals(tab)?"41개 실제 상황 · 시나리오 버튼을 누르면 연관 기능을 순차 검사":"T01~T34 개별 실행 · 매 시험마다 ZIP 자동 저장");
        List<ScenarioCatalog.Item> items="scenario".equals(tab)?ScenarioCatalog.scenarios():ScenarioCatalog.tests();
        String lastGroup="";
        for(ScenarioCatalog.Item x:items){
            if(!lastGroup.equals(x.group)){
                lastGroup=x.group;
                TextView head=text("■ "+lastGroup,16,0xff222222,true);
                head.setPadding(dp(6),dp(14),0,dp(5));catalog.addView(head);
            }
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(5),dp(5),dp(2),dp(5));row.setBackgroundColor(items.indexOf(x)%2==0?0xfff5f6f8:Color.WHITE);
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);
            TextView nm=text(x.id+" · "+x.title,14,Color.BLACK,true);info.addView(nm);
            TextView description=text("scenario".equals(tab)?"연관 시험: "+String.join(", ",x.tests):"판정 기준: "+x.evidence,11,Color.DKGRAY,false);
            info.addView(description);
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button detail=button("내용",()->showDetails(x));
            row.addView(detail,new LinearLayout.LayoutParams(dp(54),dp(58)));
            Button go=button("실행",()->beginSelected("scenario".equals(tab)?"scenario":"test",x.id));
            row.addView(go,new LinearLayout.LayoutParams(dp(60),dp(58)));
            catalog.addView(row);
        }
        catalogScroll.post(()->catalogScroll.scrollTo(0,0));
    }
    private void showDetails(ScenarioCatalog.Item x){
        String msg=x.details+"\n\n합격/근거 기준: "+x.evidence+"\n\n"+
            ("기능시험".equals(x.group)?"적용 시나리오: ":"순차 시험: ")+String.join(", ",x.tests);
        new AlertDialog.Builder(this).setTitle(x.id+" · "+x.title)
            .setMessage(msg).setNegativeButton("닫기",null)
            .setPositiveButton("이 항목 실행",(d,w)->beginSelected("기능시험".equals(x.group)?"test":"scenario",x.id)).show();
    }
    private boolean accessibilityEnabled(){
        if(CallAccessibilityService.instance!=null)return true;
        String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled!=null&&enabled.toLowerCase(Locale.ROOT).contains(getPackageName().toLowerCase(Locale.ROOT));
    }
    private void beginSelected(String mode,String id){
        if(ScenarioEngineService.active){toast("다른 검사가 실행 중입니다. 먼저 종료해 주십시오");return;}
        pendingMode=mode;pendingId=id;
        if(!accessibilityEnabled()){
            requesting=true;
            new AlertDialog.Builder(this).setTitle("접근성 서비스 허용 필요")
                .setMessage("삼성 통화 자막·문자 입력의 실제 접근성 노드를 검사하려면 'HITEL 통화 시나리오 - 화면 분석' 서비스를 켜 주십시오. 먼저 설정으로 이동합니다.")
                .setPositiveButton("설정 열기",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNegativeButton("취소",(d,w)->{pendingId="";}).show();return;
        }
        if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){
            requesting=true;requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},701);return;
        }
        boolean needsMic=id.equals("T06")||id.equals("T07")||("scenario".equals(mode)&&ScenarioCatalog.scenario(id).tests.contains("T06"));
        if(needsMic&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requesting=true;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},702);return;
        }
        boolean maySend=id.equals("T05")||id.equals("T07")||("scenario".equals(mode)&&(
                ScenarioCatalog.scenario(id).tests.contains("T05")||ScenarioCatalog.scenario(id).tests.contains("T07")));
        if(maySend){
            new AlertDialog.Builder(this).setTitle("실제 문자·TTS 시험")
                .setMessage("시험 도중 삼성 문자통화 입력창에 검증 문장을 입력하고 전송 버튼을 누를 수 있습니다. 실제 테스트 상대방과 통화 중인 경우에만 진행해 주십시오. 임의 발신·수신은 하지 않습니다.")
                .setNegativeButton("취소",(d,w)->{pendingId="";})
                .setPositiveButton("시작",(d,w)->startNow()).show();
        }else startNow();
    }
    private void startNow(){
        if(pendingId.isEmpty())return;
        String id=pendingId,mode=pendingMode;pendingId="";pendingMode="";
        Intent service=new Intent(this,ScenarioEngineService.class).setAction(ScenarioEngineService.START).putExtra("mode",mode).putExtra("id",id);
        try{startForegroundService(service);
            toast(id+" 검사가 시작되었습니다. 화면 아래에 전체 로그가 누적됩니다.");
            boolean isOutgoing=("test".equals(mode)&&id.equals("T01")) ||
                ("scenario".equals(mode)&&ScenarioCatalog.scenario(id)!=null&&
                    ScenarioCatalog.scenario(id).title.contains("A→P"));
            if(isOutgoing)handler.postDelayed(this::openDialer,1000);
        }catch(Throwable e){toast("실행 오류: "+e);}
    }
    private void openDialer(){
        try{
            LabStore.log("USER_OPEN_PHONE","사용자가 기본 전화 앱 열기를 선택함");
            Intent i=new Intent(Intent.ACTION_DIAL);startActivity(i);
        }catch(Throwable e){toast("전화 앱 호출 실패: "+e);}
    }
    private void manual(String verdict,String evidence){
        if(!ScenarioEngineService.active||ScenarioEngineService.currentTest.isEmpty()){toast("현재 진행 중인 기능시험이 없습니다");return;}
        new AlertDialog.Builder(this).setTitle("현장 확인 결과 기록")
            .setMessage(ScenarioEngineService.currentTest+"에 대해 다음 확인을 기록합니다.\n"+evidence+"\n실제 상대방의 응답에 근거하여 선택해 주십시오.")
            .setNegativeButton("취소",null).setPositiveButton("기록",(d,w)->LabStore.markManual(verdict,evidence)).show();
    }
    private void stopTest(){
        if(!ScenarioEngineService.active){toast("현재 실행 중인 검사가 없습니다");return;}
        startService(new Intent(this,ScenarioEngineService.class).setAction(ScenarioEngineService.STOP));
        toast("중단 요청. 완료된 시험 파일과 현재 기록을 저장합니다.");
    }
    private void refreshLogs(){
        File source=LabStore.logFile(this);
        if(source.length()<byteOffset){byteOffset=0;fullLines.clear();logAdapter.notifyDataSetChanged();}
        int added=0;
        try(RandomAccessFile f=new RandomAccessFile(source,"r")){
            f.seek(byteOffset);String line;
            while((line=f.readLine())!=null){
                byteOffset=f.getFilePointer();
                String raw=new String(line.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
                if(raw.isBlank())continue;
                try{
                    JSONObject o=new JSONObject(raw);
                    fullLines.add("["+o.optString("time")+"] "+o.optString("testId")+" "+o.optString("type")+"\n"+o.optString("message"));
                }catch(Exception e){fullLines.add(raw);}
                added++;
            }
        }catch(Exception e){
            // No lines are discarded if the file is temporarily inaccessible; retry next poll.
        }
        if(added>0){
            logAdapter.notifyDataSetChanged();
            if(following&&logAdapter.getCount()>0)logList.setSelection(logAdapter.getCount()-1);
            logTitle.setText("실시간 전체 로그 · "+fullLines.size()+"줄 (원본 디스크 저장)");
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);requesting=false;
        if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED&&!pendingId.isEmpty())beginSelected(pendingMode,pendingId);
        else toast("필요 권한이 없어 시험이 미검증 처리될 수 있습니다");
    }
    @Override protected void onResume(){super.onResume();
        if(requesting&&accessibilityEnabled()&&!pendingId.isEmpty()){
            requesting=false;handler.postDelayed(()->beginSelected(pendingMode,pendingId),250);
        }
    }
    @Override protected void onDestroy(){handler.removeCallbacks(monitor);super.onDestroy();}
}
