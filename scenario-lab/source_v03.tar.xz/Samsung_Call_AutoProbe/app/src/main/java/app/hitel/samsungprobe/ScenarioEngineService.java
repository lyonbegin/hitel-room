package app.hitel.samsungprobe;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Per-scenario and per-feature real-device test runner. Never replaces default dialer. */
public class ScenarioEngineService extends Service {
    public static final String START="app.hitel.scenariolab.RUN",STOP="app.hitel.scenariolab.STOP";
    public static volatile String currentTest="",currentScenario="",currentState="대기";
    public static volatile boolean active=false;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean stop=new AtomicBoolean(false);
    private boolean hadRinging,seenOffhook;
    private int lastPhoneState=-1;
    private String speechText="";
    private static final Set<String> PHONE_TESTS=new HashSet<>(Arrays.asList(
        "T01","T02","T03","T04","T05","T06","T07","T08","T09","T10","T11","T12","T13","T14","T16",
        "T19","T20","T21","T22","T23","T24","T25","T26","T27","T33"));
    private static final String[] APPS={
        "com.samsung.android.incallui","com.samsung.android.dialer","com.samsung.android.callassistant",
        "com.samsung.android.incall.contentprovider","com.samsung.android.app.telephonyui",
        "com.samsung.android.intellivoiceservice","com.skt.prod.dialer","com.skt.nugu.apollo"};
    private static class Decision {
        String status,reason;
        JSONObject evidence;
        Decision(String status,String reason,JSONObject evidence){this.status=status;this.reason=reason;this.evidence=evidence;}
    }
    @Override public void onCreate(){super.onCreate();ScenarioCatalog.load(this);LabStore.init(this);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(STOP.equals(intent.getAction())){stop.set(true);LabStore.log("STOP_REQUEST","사용자가 순차 검증 종료를 요청했습니다");return START_NOT_STICKY;}
        if(active)return START_NOT_STICKY;
        String mode=intent.getStringExtra("mode"),id=intent.getStringExtra("id");
        if(!"scenario".equals(mode)&&!"test".equals(mode))return START_NOT_STICKY;
        if(("scenario".equals(mode)&&ScenarioCatalog.scenario(id)==null)||("test".equals(mode)&&ScenarioCatalog.test(id)==null))return START_NOT_STICKY;
        active=true;stop.set(false);currentState="실행 중";currentTest="";currentScenario="scenario".equals(mode)?id:"";
        try{startNotification();}catch(Throwable e){active=false;currentState="알림 서비스 오류: "+e;stopSelf();return START_NOT_STICKY;}
        worker.execute(()->executeRun(mode,id));
        return START_NOT_STICKY;
    }
    private void startNotification(){
        String channel="call_scenario_lab_v1";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(channel,"통화 시나리오 실시간 검증",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_NEW_TASK),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopAction=PendingIntent.getService(this,2,new Intent(this,ScenarioEngineService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,channel)
            .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("통화 시나리오 검사 및 로그 기록 중")
            .setContentText("각 항목 결과는 Downloads 폴더에 독립 저장됩니다")
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"테스트 종료 및 저장",stopAction).build()).build();
        startForeground(826,n);
    }
    private void executeRun(String mode,String id){
        try{
            LabStore.begin(this,mode,id);
            if(CallAccessibilityService.instance!=null)CallAccessibilityService.instance.resetEvidence();
            List<String> ids=new ArrayList<>();
            if("scenario".equals(mode))ids.addAll(ScenarioCatalog.scenario(id).tests);else ids.add(id);
            collectSystemEvidence();
            LabStore.log("PLAN",id+" → "+String.join(" → ",ids));
            for(String next:ids){
                if(stop.get())break;
                currentTest=next;LabStore.startTest(next);
                try{
                    CallAccessibilityService access=CallAccessibilityService.instance;
                    if(access!=null){access.scanBlocking("start_"+next);access.captureScreenshot("start_"+next);}
                    Decision result=perform(next);
                    if(access!=null)access.scanBlocking("end_"+next);
                    LabStore.finishTest(this,result.status,result.reason,result.evidence);
                }catch(Throwable e){
                    LabStore.log("TEST_EXCEPTION",next+": "+e);
                    LabStore.finishTest(this,"FAIL","테스트 실행 예외: "+e,baseEvidence(next));
                }
            }
            LabStore.finishRun(this,stop.get()?"사용자가 중단하여 기록 저장":"연관 테스트 순차 실행 종료");
        }catch(Throwable e){
            LabStore.log("ENGINE_FATAL",e.toString());
            LabStore.finishRun(this,"엔진 오류: "+e);
        }finally{
            active=false;currentTest="";currentScenario="";currentState=stop.get()?"중단 · 결과 저장":"완료 · 결과 저장";
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    private void collectSystemEvidence(){
        for(String pkg:APPS){
            try{PackageInfo pi=getPackageManager().getPackageInfo(pkg,0);
                LabStore.log("PACKAGE_INSTALLED",pkg+" "+pi.versionName);
            }catch(Exception e){LabStore.log("PACKAGE_NOT_VISIBLE",pkg+" - 미설치 또는 패키지 조회 불가");}
        }
        try{
            TelecomManager t=(TelecomManager)getSystemService(TELECOM_SERVICE);
            LabStore.log("DEFAULT_DIALER",t.getDefaultDialerPackage()+" (변경하지 않음)");
        }catch(Exception e){LabStore.log("DIALER_ERROR",e.toString());}
        LabStore.log("ACCESSIBILITY",CallAccessibilityService.instance==null?"권한/서비스 미연결":"삼성 통화 접근성 서비스 활성");
        LabStore.log("PERMISSION","READ_PHONE_STATE="+granted(Manifest.permission.READ_PHONE_STATE)+" RECORD_AUDIO="+granted(Manifest.permission.RECORD_AUDIO));
    }
    private boolean granted(String perm){return checkSelfPermission(perm)==PackageManager.PERMISSION_GRANTED;}
    private int state(){
        try{
            if(!granted(Manifest.permission.READ_PHONE_STATE))return -1;
            TelephonyManager t=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
            int s=t.getCallState();
            if(s!=lastPhoneState){lastPhoneState=s;LabStore.log("CALL_STATE",s==0?"IDLE":s==1?"RINGING":s==2?"OFFHOOK":"UNKNOWN");}
            if(s==TelephonyManager.CALL_STATE_RINGING)hadRinging=true;
            if(s==TelephonyManager.CALL_STATE_OFFHOOK)seenOffhook=true;
            return s;
        }catch(Exception e){LabStore.log("CALL_STATE_ERROR",e.toString());return -1;}
    }
    private void openCallScreen(){
        main.post(()->{
            try{
                TelecomManager telecom=(TelecomManager)getSystemService(TELECOM_SERVICE);
                telecom.showInCallScreen(false);
                LabStore.log("CALL_SCREEN_OPEN","TelecomManager.showInCallScreen(false) 요청");
            }catch(Exception e){LabStore.log("CALL_SCREEN_UNAVAILABLE",e.toString());}
        });
    }
    private boolean waitCall(int ms){
        long until=System.currentTimeMillis()+ms;
        while(!stop.get()&&System.currentTimeMillis()<until){
            int s=state();if(s==TelephonyManager.CALL_STATE_OFFHOOK)return true;
            sleep(800);
        }
        return false;
    }
    private void sleep(int ms){try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();stop.set(true);}}
    private CallAccessibilityService.Snapshot snap(String reason){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return null;
        a.scanBlocking(reason);return a.snapshot();
    }
    private JSONObject baseEvidence(String id){
        JSONObject j=new JSONObject();
        try{
            j.put("testId",id);j.put("timestamp",System.currentTimeMillis()).put("phoneState",state());
            j.put("ringingObserved",hadRinging).put("offhookObserved",seenOffhook);
            CallAccessibilityService.Snapshot a=CallAccessibilityService.instance==null?null:CallAccessibilityService.instance.snapshot();
            if(a!=null){
                j.put("accessibilityForegroundPackage",a.foregroundPackage);
                j.put("accessibilityViewIds",new JSONArray(a.ids));
                j.put("accessibilityWindowPackages",new JSONArray(a.pkgs));
                j.put("remoteTextCount",a.remoteCount).put("localTextCount",a.localCount)
                    .put("translatedTextCount",a.translatedCount).put("newRemoteWhileBackground",a.remoteBackgroundCount)
                    .put("lastRemoteText",a.lastRemote).put("lastLocalText",a.lastLocal)
                    .put("lastTranslatedText",a.lastTranslated);
            }
        }catch(Exception ignored){}
        return j;
    }
    private Decision d(String status,String reason,String test){
        LabStore.log("VERDICT",test+" = "+status+" | "+reason);
        return new Decision(status,reason,baseEvidence(test));
    }
    private Decision waitEvidence(String id,int seconds,java.util.function.Predicate<CallAccessibilityService.Snapshot> condition,String note){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스가 비활성화되어 화면 검증 불가",id);
        for(int i=0;i<seconds&&!stop.get();i++){
            CallAccessibilityService.Snapshot s=snap("trial_"+id);
            if(s!=null&&condition.test(s))return d("PASS",note+" [접근성 노드 관측]",id);
            sleep(1000);
        }
        return d("UNVERIFIED",note+" — 시험 시간 동안 필요 증거 미관측",id);
    }
    private Decision perform(String id){
        LabStore.log("STEP","["+id+"] 실제 관측과 자동검사 시작. 검증 불가능한 결과는 성공 표시하지 않습니다.");
        if(id.equals("T34")){collectSystemEvidence();return d("PASS","실제 설치 패키지, 기본 전화 역할, 접근성 상태 조회 완료 (기능 활성화까지 보증하지 않음)",id);}
        if(id.equals("T18")){
            boolean writable=LabStore.checkDownloadsWritable(this);
            return d(writable?"PASS":"FAIL",writable?
                "Downloads 파일 생성·데이터 읽기·삭제 확인 성공. 개별 시험 ZIP은 별도로 자동 저장":"Downloads 실제 쓰기·재읽기 검사가 실패하였습니다",id);
        }
        if(id.equals("T17")){
            String p=CallAccessibilityService.instance==null?"없음":"연결";
            return d("UNVERIFIED","접근성 서비스="+p+"; 언어팩·OEM 기능의 실제 사용 가능성은 삼성 화면에서 별도 판정",id);
        }
        if(id.equals("T14")||id.equals("T21")){
            String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            boolean talkback=enabled!=null&&(enabled.toLowerCase(Locale.ROOT).contains("talkback"));
            LabStore.log("TALKBACK_STATUS","TalkBack enabled="+talkback+"; enabledServices="+enabled);
            return d(talkback&&CallAccessibilityService.instance!=null?"UNVERIFIED":"NOT_TESTED",talkback?"TalkBack과 진단 접근성 서비스가 동시에 활성화됨. 실제 터치·키보드 성공은 별도 확인 필요":"TalkBack 또는 진단 접근성 서비스가 켜져 있지 않음",id);
        }
        if(id.equals("T15"))return d("UNSUPPORTED","수어 인식·수어→문자 처리 모듈은 이번 진단 APK에 아직 구현되지 않았습니다",id);
        if(id.equals("T25"))return d("UNSUPPORTED","CallScreeningService 역할 및 실제 평판 데이터베이스가 연결되지 않았습니다",id);
        if(id.equals("T27"))return d("UNSUPPORTED","보호자 등록과 실제 전달 가능한 알림 채널이 아직 연결되지 않았습니다",id);
        if(id.equals("T28"))return d("UNSUPPORTED","업체 검색을 위한 검증된 실제 사업체 API가 아직 연결되지 않았습니다",id);
        if(id.equals("T30"))return d("UNSUPPORTED","SMS 읽기 및 사용자 선택 자료 연결 기능은 현재 진단 앱에 구현되지 않았습니다",id);
        if(id.equals("T31"))return d("UNSUPPORTED","신고 접수 API와 녹음 자료 연결이 없어 실제 신고 완료를 검증할 수 없습니다",id);
        if(id.equals("T32"))return checkNetwork(id);
        if(id.equals("T29"))return d("UNVERIFIED","전사 로그는 실제로 확보되는 경우 ZIP에 보존합니다. AI 요약·일정 정확도 검증에는 원문과 실제 엔진이 필요합니다",id);
        if(id.equals("T10")||id.equals("T20"))return d("UNSUPPORTED","검증 가능한 실시간 언어 번역 엔진 및 외부전화 TTS 송출 경로는 이 진단 앱에 아직 연결되지 않았습니다",id);
        if(id.equals("T08"))return d("UNSUPPORTED","일반 앱에는 기본 이동통신 전화의 송신 원음을 강제로 차단하는 공개 API가 없습니다. OEM 내부 기능 적용은 별도 검증 필요",id);
        if(id.equals("T16"))return d("UNVERIFIED","삼성 통화 중 DTMF 입력 화면을 이용할 수 있으나 외부 ARS 분기 결과는 상대방 콜센터 증거가 필요합니다. 임의 숫자는 전송하지 않았습니다",id);
        if(id.equals("T22")||id.equals("T23")){
            boolean ongoing=waitCall(15000);
            return d(ongoing?"UNVERIFIED":"NOT_TESTED",ongoing?"일반전화 통화 상태는 관측됨. 상담원 대기·실제 연결은 확인 가능한 음성·전사 근거가 추가로 필요":"대기 시험을 위한 실제 연결 통화가 없음",id);
        }
        if(id.equals("T01")){
            boolean call=waitCall(23000);
            return d(call?"UNVERIFIED":"NOT_TESTED",call?"OFFHOOK 관측, 하지만 발신 방향과 상대방 응답은 OFFHOOK만으로 확정할 수 없음":"실제 발신 연결이 관측되지 않음",id);
        }
        if(id.equals("T02")){
            boolean call=waitCall(32000);
            if(call&&hadRinging)return d("PASS","이 테스트 동안 RINGING → OFFHOOK 이력이 실제 관측됨 (상대방 음성 확인은 별도)",id);
            return d(call?"UNVERIFIED":"NOT_TESTED",call?"OFFHOOK만 확인. 수신벨 및 사용자 수락 이벤트 미확보":"기기에서 수신 통화가 확인되지 않음",id);
        }
        if(id.equals("T03")){
            if(!waitCall(17000))return d("NOT_TESTED","실제 통화 상태 없음. 전화 앱/테스트 상대방 연결 필요",id);
            openCallScreen();sleep(1200);
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            a.scanBlocking("textcall_before");
            if(a.snapshot().textCall)return d("PASS","텍스트 통화 입력창 실제 확인",id);
            a.enterTextCall();return waitEvidence(id,9,s->s.textCall,"삼성 문자통화 입력창·메시지 목록 노출");
        }
        if(id.equals("T04")){
            if(!waitCall(12000))return d("NOT_TESTED","원격 발화를 확인할 통화가 없음",id);
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            int before=a.snapshot().remoteCount;openCallScreen();
            for(int i=0;i<14&&!stop.get();i++){
                a.scanBlocking("caption_trial");
                if(a.snapshot().remoteCount>before)return d("UNVERIFIED","새 remote_message 자막 노드 관찰. 실제 음성의 내용·정확도는 상대방과 대조 필요",id);
                sleep(1000);
            }
            return d("UNVERIFIED","새 원격 발화 자막 미관측. 실제 전화 상대방 발화 및 OEM 자막 활성화 확인 필요",id);
        }
        if(id.equals("T05")||id.equals("T07"))return sendTest(id);
        if(id.equals("T06"))return runStt(id);
        if(id.equals("T09")){
            if(!waitCall(12000))return d("NOT_TESTED","번역 확인에 필요한 실제 통화 없음",id);
            return waitEvidence(id,11,s->s.translatedCount>0,"OEM 번역문 노드 존재. 번역 정확도는 원어와 수동 대조가 추가로 필요");
        }
        if(id.equals("T11")){
            CallAccessibilityService a=CallAccessibilityService.instance;
            if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
            boolean was=a.snapshot().textCall;
            return d(was?"UNVERIFIED":"NOT_TESTED",was?"문자통화 화면 관측. STT 진입 이후의 모드 유지 여부는 T06/T07 로그와 비교 필요":"진입한 문자통화 화면이 없어서 모드 유지 확인 불가",id);
        }
        if(id.equals("T12"))return backgroundTrial(id);
        if(id.equals("T13")){
            CallAccessibilityService.Snapshot s=snap("reciprocal");
            return d(s!=null&&s.remoteCount>=5&&s.localCount>=5?"UNVERIFIED":"NOT_TESTED",
                s!=null?"원격 자막="+s.remoteCount+" 발신 문자="+s.localCount+"; 각 회차의 실제 상대방 청취까지 확인해야 최종 합격":"왕복 메시지 증거 없음",id);
        }
        if(id.equals("T19"))return arsTrial(id);
        if(id.equals("T24"))return d("UNVERIFIED","실제 외국어 TTS 상대방 수신은 다른 단말 확인 필요. 현재 진단 APK가 통화 오디오를 직접 주입하지 않습니다",id);
        if(id.equals("T26"))return phishingTrial(id);
        if(id.equals("T33"))return checkNetwork(id);
        return d("UNVERIFIED","자동 검증 어댑터에서 해당 실제 기능 근거를 확보하지 못했습니다",id);
    }
    private Decision sendTest(String id){
        if(!waitCall(18000))return d("NOT_TESTED","실제 통화 연결 상태가 없어 자동 문자 송출하지 않았습니다",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        String text=id.equals("T07")?speechText:"HITEL "+id+" 기능시험 문장입니다.";
        if(text==null||text.isBlank())return d("NOT_TESTED","인식된 STT 문장이 없습니다. T06 음성인식 시험을 먼저 실행해야 합니다",id);
        a.scanBlocking("pre_send");
        if(!a.snapshot().textCall){a.enterTextCall();sleep(1300);a.scanBlocking("post_entry");}
        if(!a.snapshot().textCall)return d("NOT_TESTED","삼성 문자통화 입력창을 열지 못했습니다",id);
        int before=a.snapshot().localCount;
        boolean attempted=a.putAndSend(text);
        if(!attempted)return d("FAIL","삼성 문자 입력/전송 접근성 액션이 성공하지 못했습니다",id);
        long end=System.currentTimeMillis()+16000;boolean messageObserved=false;
        while(!stop.get()&&System.currentTimeMillis()<end){
            a.scanBlocking("send_verify");CallAccessibilityService.Snapshot s=a.snapshot();
            messageObserved|=s.localCount>before&&text.equals(s.lastLocal);
            if("PASS".equals(LabStore.manualStatus())||"FAIL".equals(LabStore.manualStatus()))break;
            sleep(900);
        }
        String human=LabStore.manualStatus();
        if("PASS".equals(human)&&messageObserved)return d("PASS","발신 local_message 노드와 상대방 청취의 사용자 현장 확인 모두 확보",id);
        if("FAIL".equals(human))return d("FAIL","사용자 현장 확인에서 상대방 TTS 미수신 보고",id);
        return d("UNVERIFIED","접근성 버튼 실행="+attempted+", 발신 목록 신규 메시지="+messageObserved+
            ". 상대방 실제 TTS 청취는 미확인(버튼 클릭 성공만으로 PASS 금지)",id);
    }
    private Decision runStt(String id){
        if(!granted(Manifest.permission.RECORD_AUDIO))return d("NOT_TESTED","마이크 권한 미허용. 앱 권한 설정 후 다시 시험",id);
        if(!SpeechRecognizer.isRecognitionAvailable(this))return d("UNSUPPORTED","휴대전화에 시스템 음성인식 서비스가 없음",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        boolean before=a!=null&&a.snapshot().textCall;
        speechText=recognize(14000);
        boolean after=a!=null&&a.snapshot().textCall;
        LabStore.log("STT_RESULT","recognized="+speechText+" textcall_before="+before+" textcall_after="+after);
        if(speechText.isEmpty())return d("UNVERIFIED","마이크 음성인식 결과 없음. 통화 중 마이크 배타 제어 여부와 OEM 정책 추가 확인 필요",id);
        return d("UNVERIFIED","음성인식 문장 수집 성공: '"+speechText+"'. 정확도 사용자 확인과 문자통화 유지 여부는 별도 검증",id);
    }
    private String recognize(int timeoutMs){
        final String[] value={""};CountDownLatch latch=new CountDownLatch(1);
        final SpeechRecognizer[] holder={null};
        main.post(()->{
            try{
                SpeechRecognizer r=SpeechRecognizer.createSpeechRecognizer(this);holder[0]=r;
                r.setRecognitionListener(new RecognitionListener(){
                    @Override public void onReadyForSpeech(Bundle params){LabStore.log("STT","음성 입력 준비됨");}
                    @Override public void onBeginningOfSpeech(){LabStore.log("STT","발화 감지");}
                    @Override public void onRmsChanged(float rms){}
                    @Override public void onBufferReceived(byte[] buffer){}
                    @Override public void onEndOfSpeech(){LabStore.log("STT","발화 종료");}
                    @Override public void onError(int error){LabStore.log("STT_ERROR","error="+error);latch.countDown();}
                    @Override public void onResults(Bundle results){
                        ArrayList<String> choices=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if(choices!=null&&!choices.isEmpty())value[0]=choices.get(0);
                        LabStore.log("STT_TEXT",value[0]);latch.countDown();
                    }
                    @Override public void onPartialResults(Bundle results){
                        ArrayList<String> texts=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if(texts!=null&&!texts.isEmpty())LabStore.log("STT_PARTIAL",texts.get(0));
                    }
                    @Override public void onEvent(int type,Bundle params){}
                });
                Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.KOREAN.toLanguageTag());
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
                r.startListening(intent);
            }catch(Throwable e){LabStore.log("STT_ERROR",e.toString());latch.countDown();}
        });
        try{latch.await(timeoutMs,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        main.post(()->{if(holder[0]!=null){holder[0].cancel();holder[0].destroy();}});
        return value[0];
    }
    private Decision backgroundTrial(String id){
        if(!waitCall(16000))return d("NOT_TESTED","전화 연결이 없는 상태에서 백그라운드 자막 시험 불가",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        a.scanBlocking("before_background");int before=a.snapshot().remoteBackgroundCount;
        a.setBackgroundTrial(true);boolean home=a.home();
        LabStore.log("BACKGROUND_TRIAL","GLOBAL_ACTION_HOME="+home+"; 다른 화면으로 나간 상태에서 실제 새로운 상대방 발화 필요");
        for(int i=0;i<12&&!stop.get();i++)sleep(1000);
        a.setBackgroundTrial(false);openCallScreen();sleep(1200);a.scanBlocking("after_background");
        int count=a.snapshot().remoteBackgroundCount-before;
        return d(count>0?"PASS":"UNVERIFIED",count>0?"백그라운드 상태에서 새로운 자막 "+count+"개 수집. 실제 발화 시점 대조 필요":"백그라운드 새 자막 미관측 (복귀 후 과거 자막은 제외)",id);
    }
    private Decision arsTrial(String id){
        if(!waitCall(14000))return d("NOT_TESTED","실제 ARS 전화가 없는 상태",id);
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        int before=a.snapshot().remoteCount;
        for(int i=0;i<14&&!stop.get();i++){
            a.scanBlocking("ars_caption");
            CallAccessibilityService.Snapshot s=a.snapshot();
            if(s.remoteCount>before){
                String value=s.lastRemote;
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9])\\s*번").matcher(value);
                List<String> menus=new ArrayList<>();while(m.find())menus.add(m.group(1)+"번");
                LabStore.log("ARS_MENU_CANDIDATE","음성자막: "+value+" / 후보 메뉴: "+menus+" (실제 ARS 번호 자동 선택 없음)");
                return d("UNVERIFIED","신규 ARS 자막 확인, 숫자 메뉴 후보="+menus+"; 사용자의 선택과 실제 DTMF 분기 미확인",id);
            }
            sleep(900);
        }
        return d("UNVERIFIED","실제 ARS 자막을 확인하지 못했습니다. SKT 에이전트콜 원본 동작 지원 여부와 별도",id);
    }
    private Decision phishingTrial(String id){
        CallAccessibilityService a=CallAccessibilityService.instance;
        if(a==null)return d("NOT_TESTED","접근성 서비스 비활성",id);
        int before=a.snapshot().remoteCount;
        for(int i=0;i<13&&!stop.get();i++){
            a.scanBlocking("risk_text");CallAccessibilityService.Snapshot s=a.snapshot();
            String text=s.lastRemote;
            if(s.remoteCount>before&&(text.contains("계좌이체")||text.contains("원격 앱")||text.contains("송금")||text.contains("인증번호"))){
                LabStore.log("FRAUD_TEXT_WARNING","실제 OEM 자막의 위험 문자열 감지: "+text+" [텍스트 단서이며 음성 기반 AI 탐지 아님]");
                return d("PASS","실제 자막에서 위험 문자열을 감지하여 경고 이벤트 생성 (피싱 확정 아님)",id);
            }
            sleep(1000);
        }
        return d("UNVERIFIED","시험 중 새로운 위험 문자열이 확인되지 않음. 보이스피싱 음성 탐지로 오인하지 않음",id);
    }
    private Decision checkNetwork(String id){
        try{
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            NetworkCapabilities cap=cm.getNetworkCapabilities(cm.getActiveNetwork());
            String connection=cap==null?"NONE":cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"WIFI":
                cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"CELLULAR":"OTHER";
            String roaming="UNKNOWN";
            if(granted(Manifest.permission.READ_PHONE_STATE)){
                TelephonyManager t=(TelephonyManager)getSystemService(TELEPHONY_SERVICE);
                roaming=String.valueOf(t.isNetworkRoaming());
            }
            LabStore.log("NETWORK","transport="+connection+" roaming="+roaming);
            return d("PASS","실제 네트워크 전송수단="+connection+", 로밍 여부="+roaming+" 조회 (통신사 baro/Home-Fi Call 구현 성공 아님)",id);
        }catch(Exception e){return d("UNVERIFIED","실제 네트워크 상태 조회 실패: "+e,id);}
    }
    @Override public void onDestroy(){stop.set(true);worker.shutdownNow();active=false;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
