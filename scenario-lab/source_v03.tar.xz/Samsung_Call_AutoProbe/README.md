# HITEL Call Scenario Lab v0.3 (2026-11-08)

## Source
`Communication_SDK_삼성_SKT_통합실사용시나리오_v3_2026-11-08.md` extracted into `app/src/main/assets/scenario_catalog_v3.json` (41 scenarios D01-D10 F01-F07 X01-X08 S01-S16; 34 tests T01-T34).

## User interface
- Tab **시나리오 41**: 41 buttons, each runs tests mapped to the specific scenario sequentially.
- Tab **기능시험 34**: 34 independently runnable feature tests.
- **전체 로그**: persistent disk-backed chronological ListView with multiline rows; **no max row or tail-only limit**. Polls `filesDir/HITEL_Call_Scenario_Lab/all_events.jsonl` incrementally every 450ms; pauses auto-scroll when the user scrolls up and resumes with `맨 아래로`.
- Current scenario/test status and manual opposing-device audio confirmation buttons.

## Files on Android
- After **each test**: `Downloads/HITEL_Txx_<run timestamp>.zip` containing `result.json`, `test.json`, `events.jsonl`, `screens/*.xml`, `screens/*.png` (if permitted), `transcripts.jsonl` (if observed).
- After **scenario**: `Downloads/HITEL_SCENARIO_D01_...zip` containing run manifest, all individual test files, all event logs, transcripts and summary.
- **전체 누적 로그 ZIP 저장** button exports all past log lines to `Downloads/HITEL_ALL_LOGS_<timestamp>.zip`.
- Data stays on the device unless the user chooses to share it. The lab never changes the default dialer or dials a number automatically.

## Evidence rules
- `PASS` only for directly observed specific evidence; counterpart TTS receipt is only PASS with observed outgoing local message and user confirmation.
- `FAIL` for explicit action failure; `UNSUPPORTED` for unimplemented/blocked API; `UNVERIFIED` for inconclusive partial observation; `NOT_TESTED` when preconditions absent.
- `CallState.OFFHOOK` does **not** establish a connected outgoing call.
- OEM private audio interception, active translation or SKT agent call cannot be inferred from package installed state.
- No custom WebRTC signaling, media routing or default-dialer replacement.

## Build
`gradle :app:assembleDebug` with Android SDK 35 / JDK 17. This package is distinct from v0.1/v0.2, preserving existing installations.

## Real-device checks pending
Device installation, service enablement, OEM text-call node visibility during a call, write to MediaStore Downloads, in-call SpeechRecognizer conflict, and unrestricted scroll behavior need on-device evidence from the emitted ZIP files. The build itself does not assert functionality.
